package com.animetv.app

import org.json.JSONArray
import org.json.JSONObject

/** Helpers for the site's guard rules (what /api/watch can answer besides the video links). */
object Guard {
    /** 403 + captcha: the site wants a game played (on a TV: the QR code). */
    fun isCaptcha(e: Exception) = e is ApiException && e.status == 403 && e.json.optBoolean("captcha")

    /** 401 + signin: a guest has used up the free videos. */
    fun isSignin(e: Exception) = e is ApiException && e.json.optBoolean("signin")

    /** 403 + open: the site wants the anime's page opened first. */
    fun isOpen(e: Exception) = e is ApiException && e.status == 403 && e.json.optBoolean("open")

    /**
     * Blocking (call from a background thread). The video links of one episode / movie.
     * If the site first wants the anime's page "opened" (after a restart, or a link that skipped it),
     * that is done quietly and the request is repeated - like the website does.
     */
    fun watch(slug: String, movie: Boolean, season: Int, episode: Int): JSONObject {
        val path = "/api/watch/$slug" + if (movie) "" else "/$season/$episode"
        var last: Exception = RuntimeException("watch failed")
        for (i in 0..2) {
            try {
                return Net.request(path)
            } catch (e: Exception) {
                last = e
                if (!isOpen(e)) break
                try { Net.request("/meta/" + (if (movie) "movie" else "series") + "/wa2:$slug.json") } catch (x: Exception) { }
            }
        }
        throw last
    }

    fun parseSources(j: JSONObject): List<Source> {
        val arr = j.optJSONArray("sources") ?: JSONArray()
        val out = ArrayList<Source>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(Source(o.optString("lang", "Default"), o.optString("quality"), o.optString("url"), o.optString("kind")))
        }
        return orderSources(out)
    }
}
