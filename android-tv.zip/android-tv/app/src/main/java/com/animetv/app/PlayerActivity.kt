package com.animetv.app

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import org.json.JSONArray
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import java.util.Locale
import kotlin.math.abs

/**
 * Full-screen native player (Media3 ExoPlayer) with remote-control handling:
 *   OK            play / pause
 *   Left / Right  seek 10 s (hold = faster and faster)
 *   Up / Down     show controls; while controls are visible: volume up / down
 *   Back          close player and return to the site
 */
class PlayerActivity : ComponentActivity() {

    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_TITLE = "title"
        const val EXTRA_START_SEC = "start_sec"
        const val EXTRA_SOURCES_JSON = "sources_json"
        const val EXTRA_SRC_INDEX = "src_index"
        const val EXTRA_VIDS_JSON = "vids_json"
        const val EXTRA_SEASON = "season"
        const val EXTRA_EPISODE = "episode"

        const val RESULT_POS_SEC = "pos_sec"
        const val RESULT_DUR_SEC = "dur_sec"
        const val RESULT_ENDED = "ended"
        const val RESULT_ERROR = "error"
        const val RESULT_JUMP_SEASON = "jump_season"
        const val RESULT_JUMP_EPISODE = "jump_episode"

        private const val USER_AGENT =
            "Mozilla/5.0 (Linux; Android 7.0; TV) AppleWebKit/537.36 (KHTML, like Gecko) " +
                    "Chrome/90.0 Safari/537.36 AnimeTV/1.0"

        private const val UI_TICK_MS = 250L
        private const val HIDE_CONTROLS_MS = 4000L
        private const val REPORT_EVERY_MS = 10_000L
        private const val SEEK_DEBOUNCE_MS = 350L
        private const val HOLD_SEEK_INTERVAL_MS = 250L
        private const val MAX_RETRIES = 2
    }

    private val handler = Handler(Looper.getMainLooper())

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var spinner: View
    private lateinit var pauseIcon: ImageView
    private lateinit var seekText: TextView
    private lateinit var volumeText: TextView
    private lateinit var topBar: View
    private lateinit var bottomBar: View
    private lateinit var titleText: TextView
    private lateinit var seekBar: ProgressBar
    private lateinit var timeCur: TextView
    private lateinit var timeDur: TextView
    private lateinit var prevBtn: TextView
    private lateinit var qualityBtn: TextView
    private lateinit var nextBtn: TextView

    private lateinit var streamUrl: String
    private var closing = false

    // optional context for the in-player Prev / Next / Quality row
    private var sources: List<Source> = emptyList()
    private var curSrcIndex = -1
    private var vids: List<Vid> = emptyList()
    private var curSeason = -1
    private var curEpisode = -1
    private var prevVid: Vid? = null
    private var nextVid: Vid? = null
    private var jumpSeason = -1
    private var jumpEpisode = -1

    // last known playback state (valid even after the player is released)
    private var lastPosMs = 0L
    private var lastDurMs = 0L
    private var lastReportAt = 0L

    // error handling
    private var retries = 0
    private var errorPosMs = -100_000L

    // controls / seeking
    private var controlsVisible = false
    private var pendingSeekMs = -1L
    private var seekAnchorMs = 0L
    private var lastHoldSeekAt = 0L
    private var holdSeeking = false

    // ------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_player)

        playerView = findViewById(R.id.player_view)
        spinner = findViewById(R.id.spinner)
        pauseIcon = findViewById(R.id.pause_icon)
        seekText = findViewById(R.id.seek_text)
        volumeText = findViewById(R.id.volume_text)
        topBar = findViewById(R.id.top_bar)
        bottomBar = findViewById(R.id.bottom_bar)
        titleText = findViewById(R.id.title_text)
        seekBar = findViewById(R.id.seek_bar)
        timeCur = findViewById(R.id.time_cur)
        timeDur = findViewById(R.id.time_dur)
        prevBtn = findViewById(R.id.prev_btn)
        qualityBtn = findViewById(R.id.quality_btn)
        nextBtn = findViewById(R.id.next_btn)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (currentFocus === prevBtn || currentFocus === qualityBtn || currentFocus === nextBtn) {
                    currentFocus?.clearFocus(); playerView.requestFocus(); return
                }
                finishWithResult(ended = false, error = null)
            }
        })

        val url = intent.getStringExtra(EXTRA_URL)
        if (url.isNullOrBlank()) {
            finishWithResult(ended = false, error = "No stream URL")
            return
        }
        streamUrl = url
        titleText.text = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        val startSec = intent.getDoubleExtra(EXTRA_START_SEC, 0.0)
        lastPosMs = if (startSec.isNaN() || startSec < 0) 0L else (startSec * 1000).toLong()

        parseExtraContext()
        setupCtrlRow()
    }

    // --------------------------------------------------------- prev/next/quality

    private fun parseExtraContext() {
        curSrcIndex = intent.getIntExtra(EXTRA_SRC_INDEX, -1)
        intent.getStringExtra(EXTRA_SOURCES_JSON)?.let { raw ->
            val arr = try { JSONArray(raw) } catch (e: Exception) { JSONArray() }
            val out = ArrayList<Source>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                out.add(Source(o.optString("lang"), o.optString("quality"), o.optString("url")))
            }
            sources = out
        }
        curSeason = intent.getIntExtra(EXTRA_SEASON, -1)
        curEpisode = intent.getIntExtra(EXTRA_EPISODE, -1)
        intent.getStringExtra(EXTRA_VIDS_JSON)?.let { raw ->
            val arr = try { JSONArray(raw) } catch (e: Exception) { JSONArray() }
            val out = ArrayList<Vid>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                out.add(Vid(o.optInt("season"), o.optInt("episode"), o.optString("title")))
            }
            vids = out
        }
        if (vids.isNotEmpty() && curSeason >= 0 && curEpisode >= 0) {
            val i = vids.indexOfFirst { it.season == curSeason && it.episode == curEpisode }
            if (i >= 0) {
                prevVid = vids.getOrNull(i - 1)
                nextVid = vids.getOrNull(i + 1)
            }
        }
    }

    private fun setupCtrlRow() {
        if (prevVid != null) {
            prevBtn.visibility = View.VISIBLE
            prevBtn.setOnClickListener { prevVid?.let { finishWithJump(it.season, it.episode) } }
        }
        if (nextVid != null) {
            nextBtn.visibility = View.VISIBLE
            nextBtn.setOnClickListener { nextVid?.let { finishWithJump(it.season, it.episode) } }
        }
        if (sources.size > 1) {
            qualityBtn.visibility = View.VISIBLE
            qualityBtn.setOnClickListener { showQualityDialog() }
        }
        val onFocus = View.OnFocusChangeListener { v, f ->
            v.animate().scaleX(if (f) 1.06f else 1f).scaleY(if (f) 1.06f else 1f).setDuration(110).start()
            if (f) { handler.removeCallbacks(hideControlsRunnable); showControls() }
        }
        prevBtn.onFocusChangeListener = onFocus
        qualityBtn.onFocusChangeListener = onFocus
        nextBtn.onFocusChangeListener = onFocus
    }

    private fun visibleCtrlButtons(): List<TextView> =
        listOf(prevBtn, qualityBtn, nextBtn).filter { it.visibility == View.VISIBLE }

    private fun showQualityDialog() {
        if (sources.isEmpty()) return
        val labels = sources.map { (it.lang + "  " + it.quality).trim() }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Quality / Language")
            .setSingleChoiceItems(labels, curSrcIndex) { d, i -> d.dismiss(); switchSource(i) }
            .show()
    }

    private fun switchSource(idx: Int) {
        if (idx < 0 || idx >= sources.size || idx == curSrcIndex) return
        curSrcIndex = idx
        capturePosition()
        val resumeMs = lastPosMs
        val src = sources[idx]
        getSharedPreferences("app", MODE_PRIVATE).edit()
            .putString("lang", src.lang).putString("q", src.quality).apply()
        releasePlayer()
        streamUrl = Net.abs(src.url)
        lastPosMs = resumeMs
        initPlayer()
    }

    private fun finishWithJump(season: Int, episode: Int) {
        if (closing) return
        closing = true
        capturePosition()
        jumpSeason = season
        jumpEpisode = episode
        val pos = lastPosMs / 1000.0
        val dur = lastDurMs / 1000.0
        PlayerEvents.lastPosSec = pos
        PlayerEvents.lastDurSec = dur
        setResult(
            RESULT_OK,
            Intent()
                .putExtra(RESULT_POS_SEC, pos)
                .putExtra(RESULT_DUR_SEC, dur)
                .putExtra(RESULT_ENDED, false)
                .putExtra(RESULT_JUMP_SEASON, jumpSeason)
                .putExtra(RESULT_JUMP_EPISODE, jumpEpisode)
        )
        finish()
    }

    override fun onStart() {
        super.onStart()
        if (!closing) {
            initPlayer()
            handler.post(uiTick)
        }
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacksAndMessages(null)
        capturePosition()
        releasePlayer()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
    }

    // --------------------------------------------------------------- player

    private fun initPlayer() {
        if (player != null) return

        // Hardware decoder first; if it fails, ExoPlayer retries with another (software) decoder.
        val renderers = DefaultRenderersFactory(this)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF)
            .setEnableDecoderFallback(true)

        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(USER_AGENT)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)
            .setAllowCrossProtocolRedirects(true)

        // Modest buffers: old TVs have little RAM.
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 40_000, 1_500, 3_000)
            .setTargetBufferBytes(32 * 1024 * 1024)
            .setPrioritizeTimeOverSizeThresholds(false)
            .setBackBuffer(10_000, false)
            .build()

        val audioAttrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        val p = ExoPlayer.Builder(this, renderers)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .setLoadControl(loadControl)
            .setAudioAttributes(audioAttrs, true)
            .setHandleAudioBecomingNoisy(true)
            .build()

        p.setSeekParameters(SeekParameters.CLOSEST_SYNC)
        p.addListener(playerListener)
        playerView.player = p
        player = p

        val item = MediaItem.Builder()
            .setUri(Uri.parse(streamUrl))
            .apply {
                if (streamUrl.contains(".m3u8", ignoreCase = true)) setMimeType(MimeTypes.APPLICATION_M3U8)
            }
            .setMediaMetadata(MediaMetadata.Builder().setTitle(titleText.text).build())
            .build()

        p.setMediaItem(item, lastPosMs)
        p.prepare()
        p.playWhenReady = true
        spinner.visibility = View.VISIBLE
        showControls()
    }

    private fun releasePlayer() {
        val p = player ?: return
        player = null
        playerView.player = null
        p.removeListener(playerListener)
        p.release()
    }

    private val playerListener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            when (playbackState) {
                Player.STATE_BUFFERING -> spinner.visibility = View.VISIBLE
                Player.STATE_READY -> spinner.visibility = View.GONE
                Player.STATE_ENDED -> {
                    capturePosition()
                    finishWithResult(ended = true, error = null)
                }
                else -> Unit
            }
            refreshPlayState()
        }

        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
            refreshPlayState()
        }

        override fun onPlayerError(error: PlaybackException) {
            handlePlayerError(error)
        }
    }

    private fun handlePlayerError(error: PlaybackException) {
        val p = player ?: return
        capturePosition()
        // A new error far from the previous one counts as a fresh problem.
        if (abs(lastPosMs - errorPosMs) > 5_000) retries = 0
        errorPosMs = lastPosMs

        if (retries < MAX_RETRIES) {
            retries++
            spinner.visibility = View.VISIBLE
            val resumeAt = lastPosMs
            handler.postDelayed({
                val cur = player
                if (cur === p && !closing) {
                    cur.seekTo(resumeAt)
                    cur.prepare()
                    cur.playWhenReady = true
                }
            }, 1000L * retries)
            return
        }
        finishWithResult(ended = false, error = "Playback error (${error.errorCodeName})")
    }

    /** Copies the live position into lastPosMs/lastDurMs. */
    private fun capturePosition() {
        val p = player ?: return
        if (pendingSeekMs < 0) lastPosMs = p.currentPosition.coerceAtLeast(0L)
        val d = p.duration
        if (d != C.TIME_UNSET && d > 0) lastDurMs = d
    }

    private fun finishWithResult(ended: Boolean, error: String?) {
        if (closing) return
        closing = true
        capturePosition()
        val posMs = if (ended && lastDurMs > 0) lastDurMs else lastPosMs
        val pos = posMs / 1000.0
        val dur = lastDurMs / 1000.0
        PlayerEvents.lastPosSec = pos
        PlayerEvents.lastDurSec = dur
        setResult(
            RESULT_OK,
            Intent()
                .putExtra(RESULT_POS_SEC, pos)
                .putExtra(RESULT_DUR_SEC, dur)
                .putExtra(RESULT_ENDED, ended)
                .putExtra(RESULT_ERROR, error)
        )
        finish()
    }

    // ------------------------------------------------------------------- UI

    private val uiTick = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, UI_TICK_MS)
        }
    }

    private fun tick() {
        val p = player ?: return
        capturePosition()
        val dur = lastDurMs
        val pos = if (pendingSeekMs >= 0) pendingSeekMs else lastPosMs

        if (controlsVisible) {
            if (dur > 0) {
                seekBar.progress = (pos * 1000 / dur).toInt().coerceIn(0, 1000)
                seekBar.secondaryProgress = (p.bufferedPosition * 1000 / dur).toInt().coerceIn(0, 1000)
            } else {
                seekBar.progress = 0
                seekBar.secondaryProgress = 0
            }
            timeCur.text = formatTime(pos)
            timeDur.text = formatTime(dur)
        }

        val now = SystemClock.uptimeMillis()
        if (p.isPlaying && now - lastReportAt >= REPORT_EVERY_MS) {
            lastReportAt = now
            PlayerEvents.report(lastPosMs / 1000.0, lastDurMs / 1000.0)
        }
    }

    private val hideControlsRunnable = Runnable {
        val p = player
        if (p != null && p.playWhenReady && pendingSeekMs < 0) setControlsVisible(false)
    }

    private fun showControls() {
        setControlsVisible(true)
        tick()
        handler.removeCallbacks(hideControlsRunnable)
        val p = player
        if (p == null || p.playWhenReady) handler.postDelayed(hideControlsRunnable, HIDE_CONTROLS_MS)
    }

    private fun setControlsVisible(visible: Boolean) {
        controlsVisible = visible
        val v = if (visible) View.VISIBLE else View.GONE
        topBar.visibility = v
        bottomBar.visibility = v
        if (!visible) {
            val cf = currentFocus
            if (cf === prevBtn || cf === qualityBtn || cf === nextBtn) { cf.clearFocus(); playerView.requestFocus() }
        }
    }

    private fun refreshPlayState() {
        val p = player ?: return
        val paused = !p.playWhenReady
        pauseIcon.visibility = if (paused && p.playbackState != Player.STATE_BUFFERING) View.VISIBLE else View.GONE
        if (paused) {
            setControlsVisible(true)
            handler.removeCallbacks(hideControlsRunnable)
            tick()
        } else {
            showControls()
        }
    }

    private fun formatTime(ms: Long): String {
        val total = (ms / 1000).coerceAtLeast(0)
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%d:%02d", m, s)
    }

    // ----------------------------------------------------------------- keys

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val down = event.action == KeyEvent.ACTION_DOWN
        val cf = currentFocus
        val onCtrlBtn = cf === prevBtn || cf === qualityBtn || cf === nextBtn
        if (onCtrlBtn) {
            // A Prev/Quality/Next pill has real D-pad focus: let Android's normal focus
            // traversal + click handling run (Left/Right move between pills, OK activates).
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> return super.dispatchKeyEvent(event)
                KeyEvent.KEYCODE_DPAD_UP -> {
                    if (down) { cf?.clearFocus(); playerView.requestFocus(); showControls() }
                    return true
                }
            }
        }
        when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_NUMPAD_ENTER,
            KeyEvent.KEYCODE_SPACE,
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                if (down && event.repeatCount == 0) togglePlay()
                return true
            }
            KeyEvent.KEYCODE_MEDIA_PLAY -> {
                if (down) setPlaying(true)
                return true
            }
            KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                if (down) setPlaying(false)
                return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                onSeekKey(event, -1, 10)
                return true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                onSeekKey(event, +1, 10)
                return true
            }
            KeyEvent.KEYCODE_MEDIA_REWIND -> {
                onSeekKey(event, -1, 30)
                return true
            }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                onSeekKey(event, +1, 30)
                return true
            }
            KeyEvent.KEYCODE_DPAD_UP -> {
                if (down) onUpDown(up = true, firstPress = event.repeatCount == 0)
                return true
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (down) onUpDown(up = false, firstPress = event.repeatCount == 0)
                return true
            }
        }
        // Back, volume keys, etc. go through the normal path.
        return super.dispatchKeyEvent(event)
    }

    private fun togglePlay() {
        val p = player ?: return
        setPlaying(!p.playWhenReady)
    }

    private fun setPlaying(play: Boolean) {
        val p = player ?: return
        p.playWhenReady = play
        refreshPlayState()
    }

    private fun onUpDown(up: Boolean, firstPress: Boolean) {
        if (!controlsVisible) {
            if (firstPress) showControls()
            return
        }
        if (!up) {
            // Down (with controls already up): jump into the Prev/Quality/Next row if it has
            // any buttons, same as the website's control bar; otherwise behaves as volume-down.
            val btns = visibleCtrlButtons()
            if (btns.isNotEmpty()) {
                btns.first().requestFocus()
                showControls()
                return
            }
        }
        changeVolume(up)
        showControls()
    }

    /**
     * Left/Right: first press = one step; holding the key repeats with growing steps
     * (10 s, 20 s, 40 s, 60 s). The real seek is applied after a short pause
     * (or when the key is released) so quick presses add up.
     */
    private fun onSeekKey(event: KeyEvent, dir: Int, baseSec: Int) {
        if (event.action == KeyEvent.ACTION_UP) {
            if (holdSeeking) applySeekNow()
            holdSeeking = false
            return
        }
        if (event.action != KeyEvent.ACTION_DOWN) return

        if (event.repeatCount == 0) {
            holdSeeking = false
            lastHoldSeekAt = event.eventTime
            seekBy(dir * baseSec * 1000L)
            return
        }
        if (baseSec != 10) return                       // media keys: single 30 s step only
        holdSeeking = true
        if (event.eventTime - lastHoldSeekAt < HOLD_SEEK_INTERVAL_MS) return
        lastHoldSeekAt = event.eventTime
        val heldMs = event.eventTime - event.downTime
        val stepSec = when {
            heldMs < 1500 -> 10
            heldMs < 3500 -> 20
            heldMs < 6000 -> 40
            else -> 60
        }
        seekBy(dir * stepSec * 1000L)
    }

    private fun seekBy(deltaMs: Long) {
        if (player == null) return
        capturePosition()
        if (pendingSeekMs < 0) seekAnchorMs = lastPosMs
        val base = if (pendingSeekMs >= 0) pendingSeekMs else lastPosMs
        var target = (base + deltaMs).coerceAtLeast(0L)
        if (lastDurMs > 0) target = target.coerceAtMost((lastDurMs - 1000L).coerceAtLeast(0L))
        pendingSeekMs = target

        val diffSec = ((target - seekAnchorMs) / 1000).toInt()
        seekText.text = String.format(Locale.US, "%+d s", diffSec)
        seekText.visibility = View.VISIBLE
        showControls()
        handler.removeCallbacks(hideSeekTextRunnable)
        handler.removeCallbacks(applySeekRunnable)
        handler.postDelayed(applySeekRunnable, SEEK_DEBOUNCE_MS)
    }

    private val applySeekRunnable = Runnable { applySeekNow() }

    private val hideSeekTextRunnable = Runnable { seekText.visibility = View.GONE }

    private fun applySeekNow() {
        handler.removeCallbacks(applySeekRunnable)
        val target = pendingSeekMs
        pendingSeekMs = -1L
        if (target >= 0) {
            player?.seekTo(target)
            lastPosMs = target
            tick()
        }
        handler.removeCallbacks(hideSeekTextRunnable)
        handler.postDelayed(hideSeekTextRunnable, 900)
    }

    private val hideVolumeRunnable = Runnable { volumeText.visibility = View.GONE }

    private fun changeVolume(up: Boolean) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val percent: Int
        if (!am.isVolumeFixed) {
            am.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                0
            )
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            percent = am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / max
        } else {
            // Output volume is fixed by the TV/HDMI chain: scale inside the player instead.
            val p = player ?: return
            p.volume = (p.volume + if (up) 0.1f else -0.1f).coerceIn(0f, 1f)
            percent = Math.round(p.volume * 100)
        }
        volumeText.text = String.format(Locale.US, "Volume %d%%", percent)
        volumeText.visibility = View.VISIBLE
        handler.removeCallbacks(hideVolumeRunnable)
        handler.postDelayed(hideVolumeRunnable, 1500)
    }
}
