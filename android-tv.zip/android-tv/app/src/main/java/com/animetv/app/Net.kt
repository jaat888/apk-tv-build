package com.animetv.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.SecureRandom
import java.util.concurrent.Executors

/** [json] is the whole error body, so callers can see the guard flags (captcha / signin / open). */
class ApiException(val status: Int, message: String, val json: JSONObject = JSONObject()) : Exception(message)

/** Tiny HTTP + JSON helper for the site's own API (no WebView involved). */
object Net {
    val main = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(4)
    // Was 3: the home grid shows many posters at once, so only 3 parallel
    // downloads meant most cards sat queued behind the first few.
    private val imgPool = Executors.newFixedThreadPool(8)

    @Volatile
    var token: String? = null

    // ---- the site's guard: a random device id (X-Device) and the TV pass (X-Captcha) ----
    private var appPrefs: android.content.SharedPreferences? = null
    @Volatile
    private var devId: String = ""
    private val DEV_RE = Regex("^[A-Za-z0-9_-]{8,40}$")

    /** The website address' host: the guard headers are only ever sent there, never to other video hosts. */
    val siteHost: String by lazy { try { URL(BuildConfig.SITE_URL).host } catch (e: Exception) { "" } }

    /** Call once with the application context (safe to call again). */
    fun init(ctx: Context) {
        if (appPrefs != null) return
        val p = ctx.getSharedPreferences("app", Context.MODE_PRIVATE)
        appPrefs = p
        val saved = p.getString("did", null)
        val id = if (saved != null && DEV_RE.matches(saved)) saved else {
            val a = "abcdefghijklmnopqrstuvwxyz0123456789"
            val r = SecureRandom()
            val fresh = String(CharArray(20) { a[r.nextInt(a.length)] })
            p.edit().putString("did", fresh).apply()
            fresh
        }
        devId = id
    }

    /** The TV pass token while it is still valid, else null. */
    fun tvToken(): String? {
        val p = appPrefs ?: return null
        val t = p.getString("tv_tok", null) ?: return null
        return if (p.getLong("tv_exp", 0L) > System.currentTimeMillis()) t else null
    }

    fun setTvPass(token: String, ttlSec: Long) {
        appPrefs?.edit()?.putString("tv_tok", token)
            ?.putLong("tv_exp", System.currentTimeMillis() + ttlSec * 1000L - 60_000L)?.apply()
    }

    fun forgetTvPass() {
        appPrefs?.edit()?.remove("tv_tok")?.remove("tv_exp")?.apply()
    }

    fun guardHeaders(): Map<String, String> {
        val m = HashMap<String, String>()
        if (devId.isNotEmpty()) m["X-Device"] = devId
        tvToken()?.let { m["X-Captcha"] = it }
        return m
    }

    private const val UA = "Mozilla/5.0 (Linux; Android 7.0; TV) AnimeTV/1.0"

    /** Relative paths ("/img/s/x", "/mq/...") are resolved against the site address. */
    fun abs(path: String): String {
        if (path.startsWith("http://") || path.startsWith("https://")) return path
        return BuildConfig.SITE_URL + (if (path.startsWith("/")) "" else "/") + path
    }

    /** Blocking. GET when body == null, otherwise POST json. Call from a background thread. */
    fun request(path: String, body: JSONObject? = null): JSONObject {
        val c = URL(abs(path)).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Accept", "application/json")
            token?.let { c.setRequestProperty("Authorization", "Bearer $it") }
            if (c.url.host == siteHost) for ((k, v) in guardHeaders()) c.setRequestProperty(k, v)
            if (body != null) {
                c.requestMethod = "POST"
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            val json = try {
                JSONObject(text)
            } catch (e: Exception) {
                JSONObject()
            }
            if (code !in 200..299) throw ApiException(code, json.optString("error", "HTTP $code"), json)
            return json
        } finally {
            c.disconnect()
        }
    }

    /** Runs [work] on a background thread, then [ok] or [fail] on the UI thread. */
    fun <T> async(work: () -> T, ok: (T) -> Unit, fail: (Exception) -> Unit = {}) {
        pool.execute {
            try {
                val r = work()
                main.post { ok(r) }
            } catch (e: Throwable) {
                // Throwable (not just Exception) so an OutOfMemoryError etc. shows the error screen instead of killing the app
                main.post { fail(if (e is Exception) e else RuntimeException(e.toString(), e)) }
            }
        }
    }

    fun loadImage(iv: ImageView, url: String, targetW: Int) = Img.load(iv, url, targetW)

    internal fun submitImage(r: Runnable) = imgPool.execute(r)
}

object Img {
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    // Disk cache: so posters already seen show instantly next time the app
    // opens, instead of re-downloading from a possibly-slow/cold server.
    // Capped so it can't grow forever - oldest files get trimmed once the
    // folder passes DISK_CACHE_MAX_BYTES.
    private const val DISK_CACHE_MAX_BYTES = 50L * 1024 * 1024
    private var diskDir: java.io.File? = null
    private val diskLock = Any()
    private var writesSinceTrim = 0

    /** Call once (e.g. from MainActivity.onCreate) before the first load(). */
    fun init(appContext: android.content.Context) {
        if (diskDir != null) return
        val d = java.io.File(appContext.cacheDir, "posters")
        if (!d.exists()) d.mkdirs()
        diskDir = d
    }

    private fun diskFile(url: String, targetW: Int): java.io.File? {
        val dir = diskDir ?: return null
        val key = java.security.MessageDigest.getInstance("MD5")
            .digest(url.toByteArray()).joinToString("") { "%02x".format(it) }
        return java.io.File(dir, "${key}_$targetW.webp")
    }

    /** Deletes oldest-first until under the cap. Only scans every 20 writes - a
     *  full directory listing on every poster save would be wasteful. */
    private fun trimDiskCacheIfNeeded() {
        val dir = diskDir ?: return
        synchronized(diskLock) {
            writesSinceTrim++
            if (writesSinceTrim < 20) return
            writesSinceTrim = 0
            val files = dir.listFiles() ?: return
            var total = files.sumOf { it.length() }
            if (total <= DISK_CACHE_MAX_BYTES) return
            for (f in files.sortedBy { it.lastModified() }) {
                if (total <= DISK_CACHE_MAX_BYTES) break
                val len = f.length()
                if (f.delete()) total -= len
            }
        }
    }

    fun load(iv: ImageView, url: String, targetW: Int, attempt: Int = 0, onSet: ((Bitmap) -> Unit)? = null) {
        iv.tag = url
        val hit = cache.get(url)
        if (hit != null) {
            iv.animate().cancel(); iv.alpha = 1f
            iv.setImageBitmap(hit)
            onSet?.invoke(hit)
            return
        }
        if (attempt == 0) { iv.animate().cancel(); iv.alpha = 1f; iv.setImageDrawable(null) }
        if (url.isEmpty()) return
        Net.submitImage(Runnable {
          try {
            // Disk cache first: skip the network entirely on a hit.
            val df = diskFile(url, targetW)
            val fromDisk = if (attempt == 0 && df != null && df.exists()) {
                try { BitmapFactory.decodeFile(df.path) } catch (e: Exception) { null }
            } else null
            if (fromDisk != null) {
                cache.put(url, fromDisk)
                Net.main.post { if (iv.tag == url) { fadeIn(iv, fromDisk); onSet?.invoke(fromDisk) } }
                return@Runnable
            }
            val bmp = try {
                download(url, targetW)
            } catch (e: Exception) {
                null
            }
            if (bmp != null) {
                cache.put(url, bmp)
                // show the poster FIRST; saving to the disk cache is best-effort and must never block it
                Net.main.post { if (iv.tag == url) { fadeIn(iv, bmp); onSet?.invoke(bmp) } }
                if (df != null) {
                    try {
                        // WEBP_LOSSY only exists on Android 11+ (API 30); older phones crashed here.
                        @Suppress("DEPRECATION")
                        val fmt = if (android.os.Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP
                        java.io.FileOutputStream(df).use { bmp.compress(fmt, 85, it) }
                        trimDiskCacheIfNeeded()
                    } catch (e: Throwable) { /* disk cache is best-effort */ }
                }
            } else if (attempt < 3) {
                // Server can be asleep for a few seconds (cold start) -> black poster forever.
                // Retry a few times with backoff instead of giving up after one failed try.
                Net.main.postDelayed({ if (iv.tag == url) load(iv, url, targetW, attempt + 1, onSet) }, 1200L * (attempt + 1))
            }
          } catch (t: Throwable) {
            cache.evictAll()   // out of memory etc.: drop cached posters, never crash the app for an image
          }
        })
    }

    /** Poster eases in instead of popping in. */
    private fun fadeIn(iv: ImageView, bmp: Bitmap) {
        iv.alpha = 0f
        iv.setImageBitmap(bmp)
        iv.animate().alpha(1f).setDuration(180).start()
    }

    private fun download(url: String, targetW: Int): Bitmap? {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 7.0; TV) AnimeTV/1.0")
            if (c.responseCode !in 200..299) return null
            val bytes = c.inputStream.use { it.readBytes() }
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
            var sample = 1
            while (o.outWidth / (sample * 2) >= targetW) sample *= 2
            val o2 = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.RGB_565
            }
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
        } finally {
            c.disconnect()
        }
    }
}
