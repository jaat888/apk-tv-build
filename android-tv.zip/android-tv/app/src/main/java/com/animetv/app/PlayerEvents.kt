package com.animetv.app

/**
 * Tiny in-process channel between PlayerActivity and MainActivity.
 * PlayerActivity reports the position every few seconds; MainActivity forwards it
 * to the page (window.onNativeProgress) so the site can keep saving watch progress.
 */
object PlayerEvents {
    @Volatile
    var progressListener: ((posSec: Double, durSec: Double) -> Unit)? = null

    /** Called when the player moves to another episode by itself (Next / Prev / auto-next). */
    @Volatile
    var episodeListener: ((season: Int, episode: Int) -> Unit)? = null

    @Volatile
    var lastPosSec: Double = 0.0

    @Volatile
    var lastDurSec: Double = 0.0

    fun reset() {
        lastPosSec = 0.0
        lastDurSec = 0.0
    }

    fun report(posSec: Double, durSec: Double) {
        lastPosSec = posSec
        lastDurSec = durSec
        progressListener?.invoke(posSec, durSec)
    }
}
