package com.animetv.app

import android.webkit.JavascriptInterface

/**
 * Exposed to the page as `window.AndroidTV`.
 *
 *   AndroidTV.play(url, title, startSeconds)
 *
 * Opens the full-screen native player. When it closes the page gets
 *   window.onNativePlayerClosed(positionSeconds, durationSeconds, ended, errorOrNull)
 * (extra arguments after positionSeconds are optional for the page to use).
 */
class AndroidTvBridge(private val activity: MainActivity) {

    @JavascriptInterface
    fun play(url: String?, title: String?, startSeconds: Double) {
        // JS interface methods run on a background thread.
        activity.runOnUiThread { activity.openPlayer(url, title, startSeconds) }
    }
}
