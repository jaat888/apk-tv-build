package com.animetv.app

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** One entry of /api/shows. */
class Show(
    val slug: String,
    val name: String,
    val poster: String,
    val movie: Boolean,
    val langs: List<String>,
    val le: IntArray?,          // latest episode [season, episode]
    val genres: List<String>,
    val rating: Double?,
    val desc: String,
    val upd: Long
)

class Vid(val season: Int, val episode: Int, val title: String)
class Prog(val slug: String, val season: Int, val episode: Int, val pos: Double, val dur: Double)
class Source(val lang: String, val quality: String, val url: String)
class Item(val show: Show, val sub: String?, val click: () -> Unit)
class CardVH(val root: LinearLayout, val iv: ImageView, val name: TextView, val sub: TextView) :
    RecyclerView.ViewHolder(root)

private class Playing(val show: Show, val season: Int, val episode: Int, val vids: List<Vid>)
private class Screen(val view: View, var lastFocus: View? = null)

class MainActivity : ComponentActivity() {

    private val ACCENT = 0xFFFF5330.toInt()
    private val BG = 0xFF0A0A0D.toInt()
    private val MUTED = 0xFF9A9AA6.toInt()

    private lateinit var root: FrameLayout
    private lateinit var spinner: ProgressBar
    private val stack = ArrayList<Screen>()

    private var shows: List<Show> = emptyList()
    private val bySlug = HashMap<String, Show>()
    private var now = 0L
    private var popular: List<String> = emptyList()
    private var trending: List<String> = emptyList()

    private var username: String? = null
    private var prog = ArrayList<Prog>()
    private var favs = ArrayList<String>()

    private var playing: Playing? = null
    private var busy = false
    private var detailRefresh: (() -> Unit)? = null
    private val metaCache = HashMap<String, Triple<List<Vid>, String, Double?>>()

    private val prefs by lazy { getSharedPreferences("app", MODE_PRIVATE) }

    private val playerLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { onPlayerClosed(it) }

    // ------------------------------------------------------------------ setup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)

        root = FrameLayout(this)
        root.setBackgroundColor(BG)
        spinner = ProgressBar(this).apply { visibility = View.GONE }
        root.addView(spinner, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.CENTER))
        setContentView(root)

        Net.token = prefs.getString("token", null)

        PlayerEvents.progressListener = { pos, dur -> playing?.let { saveProgress(it, pos, dur) } }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (stack.size > 1) pop() else finish()
            }
        })

        loadAll()
    }

    private fun loadAll() {
        clearStack()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        box.addView(label("ANIME TV", 34, true, ACCENT))
        box.addView(label("Loading…", 16, false, MUTED))
        push(box, null)
        spinner.visibility = View.VISIBLE

        Net.async({
            val j = Net.request("/api/shows")
            var me: JSONObject? = null
            if (Net.token != null) {
                me = try {
                    Net.request("/api/me")
                } catch (e: ApiException) {
                    if (e.status == 401) Net.token = null
                    null
                } catch (e: Exception) {
                    null
                }
            }
            Pair(j, me)
        }, { (j, me) ->
            spinner.visibility = View.GONE
            parseShows(j)
            if (me != null) applyMe(me)
            else if (Net.token == null) prefs.edit().remove("token").apply()
            clearStack()
            push(buildHome(), null)
        }, { e ->
            spinner.visibility = View.GONE
            clearStack()
            val box2 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
            if (isAsleep(e)) {
                box2.addView(label("ANIME TV", 28, true, ACCENT))
                box2.addView(label("Server is asleep", 20, true, Color.WHITE).apply { setPadding(0, dp(10), 0, dp(6)) })
                box2.addView(
                    label(
                        "It wakes up on its own ~30–60s after someone opens the\nsite in a browser. Open it below, wait a bit, then retry.",
                        14, false, MUTED
                    ).apply { gravity = Gravity.CENTER }
                )
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                val open = pill("Open site in browser") { openSiteInBrowser() }
                val retry = pill("Retry") { loadAll() }
                row.addView(open, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)))
                row.addView(retry, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)).apply { leftMargin = dp(12) })
                box2.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(22) })
                push(box2, open)
            } else {
                box2.addView(label("Could not load", 24, true, Color.WHITE))
                box2.addView(label(e.message ?: "Network error", 14, false, MUTED))
                val retry = pill("Retry") { loadAll() }
                box2.addView(retry, LinearLayout.LayoutParams(dp(160), dp(48)).apply { topMargin = dp(20) })
                push(box2, retry)
            }
        })
    }

    /** True for a 503 (server asleep / cold-starting) or a connect timeout, which usually means the same thing. */
    private fun isAsleep(e: Exception): Boolean =
        (e is ApiException && e.status == 503) ||
            e is java.net.SocketTimeoutException ||
            e is java.net.ConnectException

    private fun openSiteInBrowser() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(BuildConfig.SITE_URL)))
        } catch (ex: Exception) {
            toast("No browser app found on this device")
        }
    }

    private fun parseShows(j: JSONObject) {
        val arr = j.optJSONArray("shows") ?: JSONArray()
        val list = ArrayList<Show>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val le = o.optJSONArray("le")
            list.add(
                Show(
                    slug = o.optString("slug"),
                    name = o.optString("name"),
                    poster = o.optString("poster"),
                    movie = o.optBoolean("movie"),
                    langs = strList(o.optJSONArray("langs")),
                    le = if (le != null && le.length() >= 2) intArrayOf(le.optInt(0), le.optInt(1)) else null,
                    genres = strList(o.optJSONArray("genres")),
                    rating = if (o.isNull("rating")) null else o.optDouble("rating"),
                    desc = o.optString("d"),
                    upd = o.optLong("upd")
                )
            )
        }
        shows = list
        bySlug.clear()
        for (s in list) bySlug[s.slug] = s
        now = j.optLong("now", System.currentTimeMillis() / 1000)
        popular = strList(j.optJSONArray("popular"))
        trending = strList(j.optJSONArray("trending")).ifEmpty { popular }
    }

    private fun applyMe(me: JSONObject) {
        username = me.optJSONObject("user")?.optString("username")
        prog.clear()
        val p = me.optJSONArray("progress") ?: JSONArray()
        for (i in 0 until p.length()) {
            val o = p.optJSONObject(i) ?: continue
            prog.add(Prog(o.optString("slug"), o.optInt("season"), o.optInt("episode"), o.optDouble("pos"), o.optDouble("dur")))
        }
        favs = ArrayList(strList(me.optJSONArray("favs")))
    }

    private fun strList(a: JSONArray?): List<String> {
        if (a == null) return emptyList()
        val out = ArrayList<String>(a.length())
        for (i in 0 until a.length()) out.add(a.optString(i))
        return out
    }

    // ------------------------------------------------------------------ home

    private fun buildHome(): View {
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false; clipChildren = false }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(32), dp(20), dp(32), dp(40))
            clipChildren = false
        }
        scroll.addView(col)

        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(label("ANIME TV", 26, true, ACCENT), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val search = pill("Search") { openBrowse() }
        val browse = pill("Browse all") { openBrowse() }
        val acct = pill(username ?: "Sign in") { openAccount() }
        for (b in listOf(search, browse, acct)) {
            head.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)).apply { leftMargin = dp(10) })
        }
        col.addView(head)

        // Continue watching
        val cont = prog.mapNotNull { p ->
            val s = bySlug[p.slug] ?: return@mapNotNull null
            val pct = if (p.dur > 0) (p.pos * 100 / p.dur).toInt().coerceIn(0, 100) else 0
            val sub = if (s.movie) "$pct% watched" else "S${p.season} · E${p.episode} · $pct%"
            Item(s, sub) { resume(s, p) }
        }
        row(col, "Continue watching", cont)

        val favItems = favs.mapNotNull { bySlug[it] }.map { s -> Item(s, epLabel(s)) { openDetail(s) } }
        row(col, "My list", favItems)

        row(col, "Trending", trending.mapNotNull { bySlug[it] }.map { s -> Item(s, epLabel(s)) { openDetail(s) } })

        var fresh = shows.filter { it.upd > 0 && now - it.upd < 7 * 86400 }.sortedByDescending { it.upd }
        if (fresh.isEmpty()) fresh = shows.filter { it.upd > 0 }.sortedByDescending { it.upd }
        row(col, "New episodes", fresh.map { s -> Item(s, epLabel(s)) { openDetail(s) } })

        row(col, "Popular", popular.mapNotNull { bySlug[it] }.map { s -> Item(s, epLabel(s)) { openDetail(s) } })

        for (l in listOf("Hindi", "Tamil", "Telugu")) {
            val items = shows.filter { !it.movie && it.poster.isNotEmpty() && it.langs.contains(l) }
                .sortedByDescending { it.upd }
            row(col, "$l dubbed", items.map { s -> Item(s, epLabel(s)) { openDetail(s) } })
        }

        val movies = shows.filter { it.movie && it.poster.isNotEmpty() }.sortedByDescending { it.upd }
        row(col, "Movies", movies.map { s -> Item(s, epLabel(s)) { openDetail(s) } })

        return scroll
    }

    private fun row(col: LinearLayout, title: String, items: List<Item>) {
        if (items.isEmpty()) return
        col.addView(label(title, 18, true, Color.WHITE).apply { setPadding(dp(4), dp(18), 0, dp(6)) })
        val hs = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            clipChildren = false
            clipToPadding = false
        }
        val lin = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; clipChildren = false }
        for (item in items.take(20)) {
            val vh = newCard()
            bind(vh, item.show, item.sub, item.click)
            lin.addView(vh.root, LinearLayout.LayoutParams(dp(148), ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        hs.addView(lin)
        col.addView(hs)
    }

    private fun epLabel(s: Show): String =
        s.le?.let { "S${it[0]} · E${it[1]}" } ?: if (s.langs.isNotEmpty()) s.langs.take(3).joinToString(" · ") else "Movie"

    private fun rebuildHome() {
        if (stack.isEmpty()) return
        val old = stack[0]
        val idx = root.indexOfChild(old.view)
        val vis = old.view.visibility
        root.removeView(old.view)
        val v = buildHome()
        v.visibility = vis
        root.addView(v, idx, FrameLayout.LayoutParams(-1, -1))
        stack[0] = Screen(v)
        if (stack.size == 1) v.post { v.requestFocus() }
    }

    // ------------------------------------------------------------------ browse / search

    private fun openBrowse() {
        var type = 0
        var query = ""
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(32), dp(20), dp(32), 0) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val edit = EditText(this).apply {
            hint = "Search anime…"
            setHintTextColor(MUTED)
            setTextColor(Color.WHITE)
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT
            setPadding(dp(16), 0, dp(16), 0)
            background = pillBg()
            textSize = 16f
            isFocusable = true
        }
        bar.addView(edit, LinearLayout.LayoutParams(0, dp(44), 1f))
        val chips = ArrayList<TextView>()
        val gridAdapter = GridAdapter { openDetail(it) }
        fun refilter() {
            val toks = query.lowercase(Locale.ROOT).split(" ").filter { it.isNotEmpty() }
            gridAdapter.items = shows.filter { s ->
                (type == 0 || (type == 1 && !s.movie) || (type == 2 && s.movie)) &&
                    toks.all { s.name.lowercase(Locale.ROOT).contains(it) }
            }
            gridAdapter.notifyDataSetChanged()
        }
        listOf("All", "Series", "Movies").forEachIndexed { i, t ->
            val c = pill(t) {
                type = i
                chips.forEachIndexed { j, ch -> ch.isSelected = j == i }
                refilter()
            }
            c.isSelected = i == 0
            chips.add(c)
            bar.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)).apply { leftMargin = dp(10) })
        }
        col.addView(bar)

        val span = maxOf(3, resources.displayMetrics.widthPixels / dp(172))
        val rv = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@MainActivity, span)
            this.adapter = gridAdapter
            clipChildren = false
            clipToPadding = false
            setPadding(0, dp(16), 0, dp(24))
            descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        }
        col.addView(rv, LinearLayout.LayoutParams(-1, 0, 1f))

        val handler = Net.main
        val run = Runnable { refilter() }
        edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString() ?: ""
                handler.removeCallbacks(run)
                handler.postDelayed(run, 250)
            }
        })
        refilter()
        push(col, chips[0])
    }

    private inner class GridAdapter(val click: (Show) -> Unit) : RecyclerView.Adapter<CardVH>() {
        var items: List<Show> = emptyList()
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardVH {
            val vh = newCard()
            vh.root.layoutParams = RecyclerView.LayoutParams(dp(160), ViewGroup.LayoutParams.WRAP_CONTENT)
            return vh
        }

        override fun getItemCount() = items.size
        override fun onBindViewHolder(holder: CardVH, position: Int) {
            val s = items[position]
            bind(holder, s, epLabel(s)) { click(s) }
        }
    }

    // ------------------------------------------------------------------ detail

    private fun openDetail(s: Show) {
        val vidsAll = ArrayList<Vid>()
        var season = 0
        val seen = HashSet<String>()

        val page = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(40), dp(28), dp(40), dp(16)) }

        val poster = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(0xFF1A1A22.toInt()) }
        Img.load(poster, Net.abs(s.poster), dp(260))
        page.addView(poster, LinearLayout.LayoutParams(dp(220), dp(320)))

        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(28), 0, 0, 0) }
        page.addView(right, LinearLayout.LayoutParams(0, -1, 1f))

        right.addView(label(s.name, 26, true, Color.WHITE).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END })
        val metaParts = ArrayList<String>()
        s.rating?.let { metaParts.add("★ " + String.format(Locale.US, "%.1f", it)) }
        if (s.genres.isNotEmpty()) metaParts.add(s.genres.take(3).joinToString(" · "))
        if (s.langs.isNotEmpty()) metaParts.add(s.langs.take(3).joinToString("/") + " dub")
        right.addView(label(metaParts.joinToString("   "), 13, false, MUTED).apply { setPadding(0, dp(4), 0, dp(6)) })
        val desc = label(s.desc, 14, false, 0xFFD0D0D8.toInt()).apply { maxLines = 4; ellipsize = TextUtils.TruncateAt.END }
        right.addView(desc)

        val btnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(14), 0, dp(10)) }
        val playBtn = pill("Play") {}
        btnRow.addView(playBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)))
        val favBtn = pill("") {}
        if (username != null) {
            btnRow.addView(favBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)).apply { leftMargin = dp(12) })
        }
        right.addView(btnRow)

        val seasonBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val seasonScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(seasonBar) }
        right.addView(seasonScroll)

        val status = label(if (s.movie) "" else "Loading episodes…", 14, false, MUTED)
        right.addView(status)

        val epAdapter = EpAdapter()
        val rv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = epAdapter
            clipToPadding = false
            setPadding(0, dp(8), 0, dp(12))
        }
        if (!s.movie) right.addView(rv, LinearLayout.LayoutParams(-1, 0, 1f))

        fun progFor() = prog.firstOrNull { it.slug == s.slug }

        fun refreshButtons() {
            val p = progFor()
            playBtn.text = when {
                p != null && s.movie -> "Resume"
                p != null -> "Resume S${p.season} E${p.episode}"
                s.movie -> "Play"
                else -> "Play S${vidsAll.firstOrNull()?.season ?: 1} E${vidsAll.firstOrNull()?.episode ?: 1}"
            }
            favBtn.text = if (favs.contains(s.slug)) "✓ In my list" else "+ My list"
            epAdapter.notifyDataSetChanged()
        }

        playBtn.setOnClickListener {
            val p = progFor()
            when {
                p != null -> play(s, p.season, p.episode, if (p.dur > 0 && p.pos / p.dur > 0.95) 0.0 else p.pos, vidsAll, false)
                s.movie -> play(s, 0, 0, 0.0, vidsAll, false)
                vidsAll.isEmpty() -> toast("Episodes are still loading")
                else -> play(s, vidsAll[0].season, vidsAll[0].episode, 0.0, vidsAll, false)
            }
        }
        favBtn.setOnClickListener {
            val on = !favs.contains(s.slug)
            if (on) favs.add(0, s.slug) else favs.remove(s.slug)
            refreshButtons()
            Net.async({ Net.request("/api/fav", JSONObject().put("slug", s.slug).put("on", on)) }, {}, {})
        }

        fun showSeason(n: Int) {
            season = n
            epAdapter.items = vidsAll.filter { it.season == n }
            for (i in 0 until seasonBar.childCount) seasonBar.getChildAt(i).isSelected = (seasonBar.getChildAt(i).tag == n)
            epAdapter.notifyDataSetChanged()
        }

        epAdapter.onClick = { v -> play(s, v.season, v.episode, 0.0, vidsAll, false) }
        epAdapter.state = { v ->
            val p = progFor()
            when {
                seen.contains("${v.season}:${v.episode}") -> "✓"
                p != null && p.season == v.season && p.episode == v.episode && p.dur > 0 ->
                    "${(p.pos * 100 / p.dur).toInt().coerceIn(0, 100)}%"
                else -> ""
            }
        }

        fun fillMeta(vids: List<Vid>) {
            vidsAll.clear()
            vidsAll.addAll(vids)
            status.visibility = if (vids.isEmpty() && !s.movie) View.VISIBLE else View.GONE
            if (vids.isEmpty() && !s.movie) status.text = "No episodes found"
            seasonBar.removeAllViews()
            val seasons = vids.map { it.season }.distinct().sorted()
            if (seasons.size > 1) {
                for (n in seasons) {
                    val c = pill("Season $n") { showSeason(n) }
                    c.tag = n
                    seasonBar.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)).apply { rightMargin = dp(8) })
                }
            }
            showSeason(progFor()?.season?.takeIf { seasons.contains(it) } ?: seasons.firstOrNull() ?: 1)
            refreshButtons()
        }

        refreshButtons()
        detailRefresh = { refreshButtons() }

        val cached = metaCache[s.slug]
        if (cached != null) {
            fillMeta(cached.first)
        } else {
            Net.async({
                val type = if (s.movie) "movie" else "series"
                val m = Net.request("/meta/$type/raretoons2:${s.slug}.json").optJSONObject("meta") ?: JSONObject()
                val vids = ArrayList<Vid>()
                val arr = m.optJSONArray("videos") ?: JSONArray()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    vids.add(Vid(o.optInt("season", 1), o.optInt("episode"), o.optString("title")))
                }
                vids.sortWith(compareBy({ it.season }, { it.episode }))
                Triple(vids, m.optString("overview"), if (m.isNull("rating")) null else m.optDouble("rating"))
            }, { t ->
                metaCache[s.slug] = t
                if (desc.text.isNullOrEmpty() && t.second.isNotEmpty()) desc.text = t.second
                fillMeta(t.first)
            }, { e ->
                status.text = "Could not load episodes: ${e.message}"
            })
        }

        if (username != null && !s.movie) {
            Net.async({
                val a = Net.request("/api/seen/${s.slug}").optJSONArray("seen")
                strList(a)
            }, { list ->
                seen.addAll(list)
                epAdapter.notifyDataSetChanged()
            }, {})
        }

        push(page, playBtn)
    }

    private inner class EpAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        var items: List<Vid> = emptyList()
        var onClick: (Vid) -> Unit = {}
        var state: (Vid) -> String = { "" }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), 0, dp(14), 0)
                layoutParams = RecyclerView.LayoutParams(-1, dp(48))
            }
            val num = label("", 15, true, ACCENT).apply { tag = "n" }
            val title = label("", 15, false, Color.WHITE).apply {
                tag = "t"
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            val st = label("", 13, true, MUTED).apply { tag = "s" }
            row.addView(num, LinearLayout.LayoutParams(dp(64), ViewGroup.LayoutParams.WRAP_CONTENT))
            row.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(st, LinearLayout.LayoutParams(dp(56), ViewGroup.LayoutParams.WRAP_CONTENT))
            focusStyle(row, 1.02f)
            return object : RecyclerView.ViewHolder(row) {}
        }

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: RecyclerView.ViewHolder, position: Int) {
            val v = items[position]
            val r = h.itemView as LinearLayout
            (r.findViewWithTag<TextView>("n")).text = "E${v.episode}"
            (r.findViewWithTag<TextView>("t")).text = v.title
            (r.findViewWithTag<TextView>("s")).text = state(v)
            r.setOnClickListener { onClick(v) }
        }
    }

    // ------------------------------------------------------------------ playback

    private fun resume(s: Show, p: Prog) {
        val start = if (p.dur > 0 && p.pos / p.dur > 0.95) 0.0 else p.pos
        val vids = metaCache[s.slug]?.first ?: emptyList()
        play(s, p.season, p.episode, start, vids, false)
    }

    private fun play(s: Show, season: Int, episode: Int, start: Double, vidsIn: List<Vid>, auto: Boolean) {
        if (busy) return
        busy = true
        spinner.visibility = View.VISIBLE
        Net.async({
            val path = "/api/watch/${s.slug}" + if (s.movie) "" else "/$season/$episode"
            val arr = Net.request(path).optJSONArray("sources") ?: JSONArray()
            val out = ArrayList<Source>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                out.add(Source(o.optString("lang", "Default"), o.optString("quality"), o.optString("url")))
            }
            out
        }, { sources ->
            busy = false
            spinner.visibility = View.GONE
            if (sources.isEmpty()) {
                toast("No stream available for this one")
                return@async
            }
            pickSource(sources, auto) { src ->
                prefs.edit().putString("lang", src.lang).putString("q", src.quality).apply()
                launchPlayer(s, season, episode, start, vidsIn, sources, src)
            }
        }, { e ->
            busy = false
            spinner.visibility = View.GONE
            if (isAsleep(e)) {
                AlertDialog.Builder(this)
                    .setTitle("Server is asleep")
                    .setMessage("It wakes up on its own ~30\u201360s after someone opens the site in a browser. Open it, wait a bit, then try again.")
                    .setPositiveButton("Open site in browser") { _, _ -> openSiteInBrowser() }
                    .setNegativeButton("Close", null)
                    .show()
            } else {
                toast("Could not load stream: ${e.message}")
            }
        })
    }

    private fun pickSource(sources: List<Source>, auto: Boolean, cb: (Source) -> Unit) {
        val lang = prefs.getString("lang", null)
        val q = prefs.getString("q", null)
        val saved = sources.firstOrNull { it.lang == lang && it.quality == q }
            ?: sources.firstOrNull { it.lang == lang }
        if (sources.size == 1) return cb(sources[0])
        if (auto && saved != null) return cb(saved)
        val ordered = if (saved != null) listOf(saved) + sources.filter { it !== saved } else sources
        val labels = ordered.map { (it.lang + "  " + it.quality).trim() }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Choose language / quality")
            .setItems(labels) { _, i -> cb(ordered[i]) }
            .show()
    }

    private fun launchPlayer(s: Show, season: Int, episode: Int, start: Double, vids: List<Vid>, sources: List<Source>, src: Source) {
        val url = Net.abs(src.url)
        if (!url.startsWith("https://")) {
            toast("This stream is not HTTPS, cannot play")
            return
        }
        playing = Playing(s, season, episode, vids)
        PlayerEvents.reset()
        val title = if (s.movie) s.name else "${s.name}  S$season E$episode"
        val srcArr = JSONArray()
        var srcIdx = 0
        sources.forEachIndexed { i, x ->
            if (x === src) srcIdx = i
            srcArr.put(JSONObject().put("lang", x.lang).put("quality", x.quality).put("url", x.url))
        }
        val vidArr = JSONArray()
        vids.forEach { vidArr.put(JSONObject().put("season", it.season).put("episode", it.episode).put("title", it.title)) }
        playerLauncher.launch(
            Intent(this, PlayerActivity::class.java)
                .putExtra(PlayerActivity.EXTRA_URL, url)
                .putExtra(PlayerActivity.EXTRA_TITLE, title)
                .putExtra(PlayerActivity.EXTRA_START_SEC, start)
                .putExtra(PlayerActivity.EXTRA_SOURCES_JSON, srcArr.toString())
                .putExtra(PlayerActivity.EXTRA_SRC_INDEX, srcIdx)
                .putExtra(PlayerActivity.EXTRA_VIDS_JSON, vidArr.toString())
                .putExtra(PlayerActivity.EXTRA_SEASON, season)
                .putExtra(PlayerActivity.EXTRA_EPISODE, episode)
        )
    }

    private fun onPlayerClosed(result: ActivityResult) {
        val pl = playing ?: return
        val d = result.data
        val pos = d?.getDoubleExtra(PlayerActivity.RESULT_POS_SEC, PlayerEvents.lastPosSec) ?: PlayerEvents.lastPosSec
        val dur = d?.getDoubleExtra(PlayerActivity.RESULT_DUR_SEC, PlayerEvents.lastDurSec) ?: PlayerEvents.lastDurSec
        val ended = d?.getBooleanExtra(PlayerActivity.RESULT_ENDED, false) ?: false
        val error = d?.getStringExtra(PlayerActivity.RESULT_ERROR)
        if (!error.isNullOrEmpty()) toast("Playback error: $error")
        if (dur > 0) saveProgress(pl, if (ended) dur else pos, dur)

        // Prev / Next pill pressed inside the player -> go straight to that episode.
        val jumpSeason = d?.getIntExtra(PlayerActivity.RESULT_JUMP_SEASON, -1) ?: -1
        val jumpEpisode = d?.getIntExtra(PlayerActivity.RESULT_JUMP_EPISODE, -1) ?: -1
        if (jumpSeason >= 0 && jumpEpisode >= 0) {
            play(pl.show, jumpSeason, jumpEpisode, 0.0, pl.vids, false)
            return
        }

        detailRefresh?.invoke()
        if (stack.size == 1) rebuildHome()

        if (ended && !pl.show.movie) {
            val i = pl.vids.indexOfFirst { it.season == pl.season && it.episode == pl.episode }
            val next = if (i >= 0) pl.vids.getOrNull(i + 1) else null
            if (next != null) play(pl.show, next.season, next.episode, 0.0, pl.vids, true)
        }
    }

    private fun saveProgress(p: Playing, pos: Double, dur: Double) {
        if (dur <= 0) return
        val i = prog.indexOfFirst { it.slug == p.show.slug }
        if (i >= 0) prog.removeAt(i)
        prog.add(0, Prog(p.show.slug, p.season, p.episode, pos, dur))
        if (Net.token == null) return
        val body = JSONObject().put("slug", p.show.slug).put("season", p.season).put("episode", p.episode)
            .put("pos", pos).put("dur", dur)
        Net.async({ Net.request("/api/progress", body) }, {}, {})
    }

    // ------------------------------------------------------------------ account

    private fun openAccount() {
        if (username != null) {
            AlertDialog.Builder(this)
                .setTitle("Signed in as $username")
                .setPositiveButton("Sign out") { _, _ ->
                    Net.async({ Net.request("/api/logout", JSONObject()) }, {}, {})
                    Net.token = null
                    prefs.edit().remove("token").apply()
                    username = null
                    prog.clear()
                    favs.clear()
                    rebuildHome()
                }
                .setNegativeButton("Close", null)
                .show()
            return
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(12), dp(24), 0) }
        val u = EditText(this).apply { hint = "Username"; setSingleLine(); inputType = InputType.TYPE_CLASS_TEXT }
        val p = EditText(this).apply {
            hint = "Password"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        box.addView(u)
        box.addView(p)
        fun submit(mode: String) {
            val body = JSONObject().put("username", u.text.toString().trim()).put("password", p.text.toString())
            spinner.visibility = View.VISIBLE
            Net.async({
                val j = Net.request("/api/$mode", body)
                Net.token = j.optString("token")
                Pair(j, Net.request("/api/me"))
            }, { (j, me) ->
                spinner.visibility = View.GONE
                prefs.edit().putString("token", j.optString("token")).apply()
                applyMe(me)
                rebuildHome()
            }, { e ->
                spinner.visibility = View.GONE
                Net.token = null
                toast(e.message ?: "Failed")
            })
        }
        AlertDialog.Builder(this)
            .setTitle("Account")
            .setView(box)
            .setPositiveButton("Sign in") { _, _ -> submit("login") }
            .setNeutralButton("Create account") { _, _ -> submit("signup") }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ------------------------------------------------------------------ screens / views

    private fun push(view: View, focus: View?) {
        stack.lastOrNull()?.let {
            it.lastFocus = currentFocus
            it.view.visibility = View.GONE
        }
        root.addView(view, root.childCount - 1, FrameLayout.LayoutParams(-1, -1))
        stack.add(Screen(view))
        view.post { (focus ?: view).requestFocus() }
    }

    private fun pop() {
        if (stack.size <= 1) return
        val top = stack.removeAt(stack.size - 1)
        root.removeView(top.view)
        detailRefresh = null
        val prev = stack.last()
        prev.view.visibility = View.VISIBLE
        prev.view.post { (prev.lastFocus ?: prev.view).requestFocus() }
    }

    private fun clearStack() {
        for (s in stack) root.removeView(s.view)
        stack.clear()
        detailRefresh = null
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun label(text: String, sp: Int, bold: Boolean, color: Int) = TextView(this).apply {
        this.text = text
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp.toFloat())
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.START
    }

    private fun rr(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }

    private fun pillBg() = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_focused), rr(ACCENT, 20))
        addState(intArrayOf(android.R.attr.state_selected), rr(0xFF7A2A19.toInt(), 20))
        addState(intArrayOf(), rr(0xFF26262F.toInt(), 20))
    }

    private fun pill(text: String, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(dp(18), 0, dp(18), 0)
        background = pillBg()
        isFocusable = true
        isClickable = true
        setOnClickListener { onClick() }
        onFocusChangeListener = View.OnFocusChangeListener { v, f ->
            v.animate().scaleX(if (f) 1.05f else 1f).scaleY(if (f) 1.05f else 1f).setDuration(110).start()
        }
    }

    /** Accent frame + slight zoom when a card/row gets D-pad focus. */
    private fun focusStyle(v: View, scale: Float) {
        v.isFocusable = true
        v.isClickable = true
        v.background = StateListDrawable().apply {
            addState(
                intArrayOf(android.R.attr.state_focused),
                GradientDrawable().apply {
                    setColor(0x22FFFFFF)
                    cornerRadius = dp(8).toFloat()
                    setStroke(dp(3), ACCENT)
                }
            )
            addState(intArrayOf(), GradientDrawable().apply { setColor(Color.TRANSPARENT) })
        }
        v.onFocusChangeListener = View.OnFocusChangeListener { x, f ->
            x.animate().scaleX(if (f) scale else 1f).scaleY(if (f) scale else 1f).setDuration(110).start()
            if (f) {
                x.bringToFront()
                // Scroll every ancestor HorizontalScrollView/ScrollView into place the instant
                // focus lands here, instead of waiting on the platform's own lazy scroll-into-view
                // (that lag is what made the D-pad feel like it needed two presses per row).
                x.post { x.parent?.requestChildRectangleOnScreen(x, android.graphics.Rect(0, 0, x.width, x.height), false) }
            }
        }
    }

    private fun newCard(): CardVH {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
            clipChildren = false
        }
        val iv = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0xFF1A1A22.toInt())
        }
        col.addView(iv, LinearLayout.LayoutParams(dp(136), dp(190)))
        val name = label("", 13, true, Color.WHITE).apply {
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setPadding(0, dp(6), 0, 0)
            minLines = 2
        }
        col.addView(name, LinearLayout.LayoutParams(dp(136), ViewGroup.LayoutParams.WRAP_CONTENT))
        val sub = label("", 11, false, MUTED).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        col.addView(sub, LinearLayout.LayoutParams(dp(136), ViewGroup.LayoutParams.WRAP_CONTENT))
        focusStyle(col, 1.06f)
        return CardVH(col, iv, name, sub)
    }

    private fun bind(h: CardVH, s: Show, sub: String?, click: () -> Unit) {
        h.name.text = s.name
        h.sub.text = sub ?: ""
        Img.load(h.iv, Net.abs(s.poster), dp(136))
        h.root.setOnClickListener { click() }
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
    }

    override fun onDestroy() {
        PlayerEvents.progressListener = null
        super.onDestroy()
    }
}
