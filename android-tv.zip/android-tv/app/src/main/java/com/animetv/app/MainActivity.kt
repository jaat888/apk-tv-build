package com.animetv.app

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONObject
import java.net.URL
import java.util.Locale

class MainActivity : ComponentActivity() {

    private lateinit var webView: WebView
    private lateinit var errorBox: View
    private lateinit var loading: View
    private lateinit var retryBtn: Button

    private var pageFailed = false

    private val playerLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            onPlayerClosed(result)
        }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webview)
        errorBox = findViewById(R.id.error_box)
        loading = findViewById(R.id.loading)
        retryBtn = findViewById(R.id.retry_btn)

        retryBtn.setOnClickListener {
            pageFailed = false
            errorBox.visibility = View.GONE
            loading.visibility = View.VISIBLE
            webView.requestFocus()
            webView.loadUrl(BuildConfig.SITE_URL)
        }

        setupWebView()

        // Forward player progress to the page (keeps the site's "continue watching" fresh).
        PlayerEvents.progressListener = { pos, dur ->
            webView.evaluateJavascript(
                "window.onNativeProgress&&window.onNativeProgress(${num(pos)},${num(dur)})", null
            )
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (errorBox.visibility == View.VISIBLE) {
                    finish()
                    return
                }
                // Let the site handle Back first (close search/modal, go to previous page).
                webView.evaluateJavascript(
                    "(function(){try{return window.tvGoBack?window.tvGoBack():null}catch(e){return null}})()"
                ) { r ->
                    when (r) {
                        "true" -> Unit                       // the page handled it
                        "false" -> finish()                  // page is at its home -> leave the app
                        else -> if (webView.canGoBack()) webView.goBack() else finish()
                    }
                }
            }
        })

        if (savedInstanceState == null || webView.restoreState(savedInstanceState) == null) {
            webView.loadUrl(BuildConfig.SITE_URL)
        }
    }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    private fun setupWebView() {
        if (BuildConfig.DEBUG) WebView.setWebContentsDebuggingEnabled(true)

        webView.isFocusable = true
        webView.isFocusableInTouchMode = true
        webView.setBackgroundColor(0xFF0A0A0D.toInt())

        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            useWideViewPort = true
            loadWithOverviewMode = false
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            allowFileAccess = false
            allowContentAccess = false
            // The "TV" word makes the site switch on its remote-control (html.tv) mode.
            userAgentString = userAgentString + " TV AnimeTV/" + BuildConfig.VERSION_NAME
        }

        CookieManager.getInstance().setAcceptCookie(true)

        // Must be added BEFORE the first loadUrl so the page sees window.AndroidTV on load.
        webView.addJavascriptInterface(AndroidTvBridge(this), "AndroidTV")

        webView.webChromeClient = object : WebChromeClient() {
            // Avoids a crash in some old WebViews when a <video> has no poster.
            override fun getDefaultVideoPoster(): Bitmap {
                return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
            }

            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (newProgress >= 70 && !pageFailed) loading.visibility = View.GONE
            }
        }

        webView.webViewClient = object : WebViewClient() {
            private val siteHost: String? = Uri.parse(BuildConfig.SITE_URL).host

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                // Stay on the site; never navigate the app to other hosts.
                return request.url.host != siteHost
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                pageFailed = false
            }

            override fun onPageFinished(view: WebView, url: String?) {
                if (!pageFailed) {
                    errorBox.visibility = View.GONE
                    loading.visibility = View.GONE
                    view.requestFocus()
                }
                CookieManager.getInstance().flush()
            }

            override fun onReceivedError(
                view: WebView, request: WebResourceRequest, error: WebResourceError
            ) {
                if (request.isForMainFrame) showLoadError()
            }

            override fun onReceivedHttpError(
                view: WebView, request: WebResourceRequest, errorResponse: WebResourceResponse
            ) {
                if (request.isForMainFrame && errorResponse.statusCode >= 500) showLoadError()
            }
        }
    }

    private fun showLoadError() {
        pageFailed = true
        loading.visibility = View.GONE
        errorBox.visibility = View.VISIBLE
        retryBtn.requestFocus()
    }

    // ---------------------------------------------------------------- player

    /** Called by the JS bridge (on the UI thread). */
    fun openPlayer(rawUrl: String?, title: String?, startSeconds: Double) {
        val url = resolveStreamUrl(rawUrl)
        if (url == null) {
            notifyClosed(0.0, 0.0, false, "Invalid or non-HTTPS stream URL")
            return
        }
        val start = if (startSeconds.isNaN() || startSeconds < 0) 0.0 else startSeconds
        PlayerEvents.reset()
        val intent = Intent(this, PlayerActivity::class.java)
            .putExtra(PlayerActivity.EXTRA_URL, url)
            .putExtra(PlayerActivity.EXTRA_TITLE, title ?: "")
            .putExtra(PlayerActivity.EXTRA_START_SEC, start)
        playerLauncher.launch(intent)
    }

    /** Relative URLs (like /mq/xxx.m3u8 from /api/watch) are resolved against the site address. */
    private fun resolveStreamUrl(raw: String?): String? {
        if (raw.isNullOrBlank()) return null
        return try {
            val u = URL(URL(BuildConfig.SITE_URL + "/"), raw.trim())
            if (u.protocol == "https") u.toString() else null
        } catch (e: Exception) {
            null
        }
    }

    private fun onPlayerClosed(result: ActivityResult) {
        val d = result.data
        val pos = d?.getDoubleExtra(PlayerActivity.RESULT_POS_SEC, PlayerEvents.lastPosSec)
            ?: PlayerEvents.lastPosSec
        val dur = d?.getDoubleExtra(PlayerActivity.RESULT_DUR_SEC, PlayerEvents.lastDurSec)
            ?: PlayerEvents.lastDurSec
        val ended = d?.getBooleanExtra(PlayerActivity.RESULT_ENDED, false) ?: false
        val error = d?.getStringExtra(PlayerActivity.RESULT_ERROR)
        webView.requestFocus()
        notifyClosed(pos, dur, ended, error)
    }

    /** window.onNativePlayerClosed(positionSeconds, durationSeconds, ended, errorOrNull) */
    private fun notifyClosed(pos: Double, dur: Double, ended: Boolean, error: String?) {
        val err = if (error.isNullOrEmpty()) "null" else JSONObject.quote(error)
        webView.evaluateJavascript(
            "window.onNativePlayerClosed&&window.onNativePlayerClosed(${num(pos)},${num(dur)},$ended,$err)",
            null
        )
    }

    private fun num(v: Double): String =
        if (v.isNaN() || v.isInfinite()) "0" else String.format(Locale.US, "%.2f", v)

    // -------------------------------------------------------------- lifecycle

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            hideSystemUi()
            if (errorBox.visibility != View.VISIBLE) webView.requestFocus()
        }
    }

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
    }

    override fun onDestroy() {
        PlayerEvents.progressListener = null
        webView.removeJavascriptInterface("AndroidTV")
        webView.destroy()
        super.onDestroy()
    }
}
