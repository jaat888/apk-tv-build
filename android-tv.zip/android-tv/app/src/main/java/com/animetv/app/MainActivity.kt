package com.animetv.app

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.Outline
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** One entry of /api/shows. */
class Show(
    val slug: String,
    val name: String,
    val poster: String,
    val movie: Boolean,
    val langs: List<String>,
    val le: IntArray?,          // latest episode [season, episode]
    val genres: List<String>,
    val rating: Double?,
    val desc: String,
    val upd: Long,
    val n: Int = 0,             // episode count
    val kind: String = "anime", // "anime" | "cartoon"
    val ord: Int = 0            // server order (higher = added later)
)

class Vid(val season: Int, val episode: Int, val title: String)
class Prog(val slug: String, val season: Int, val episode: Int, val pos: Double, val dur: Double)
class Source(val lang: String, val quality: String, val url: String)
class Item(
    val show: Show,
    val sub: String?,
    val click: () -> Unit,
    val title: String? = null,     // override card title (grouped anime -> base name)
    val badge: String? = null,     // green top-left badge ("NEW", "3 SEASONS")
    val pct: Int? = null,          // progress bar under the thumbnail (continue watching)
    val epLine: String? = null     // accent line above the title (latest-episode cards)
)
class CardVH(
    val root: LinearLayout,
    val bg: ImageView,
    val iv: ImageView,
    val ph: TextView,
    val lang: TextView,
    val en: TextView,
    val rt: TextView,
    val badge: TextView,
    val progWrap: FrameLayout,
    val prog: View,
    val epl: TextView,
    val name: TextView,
    val sub: TextView
) : RecyclerView.ViewHolder(root)

private class Playing(val show: Show, val season: Int, val episode: Int, val vids: List<Vid>)
private class Screen(val view: View, var lastFocus: View? = null)

class MainActivity : ComponentActivity() {

    private val ACCENT = 0xFFFF5330.toInt()
    private val BG = 0xFF0A0A0D.toInt()
    private val MUTED = 0xFF9A9AA6.toInt()
    private val CARD_W = 250   // dp, website rail card (wide 16:9 thumbnail)

    private lateinit var root: FrameLayout
    private lateinit var spinner: ProgressBar
    private val stack = ArrayList<Screen>()

    private var shows: List<Show> = emptyList()
    private val bySlug = HashMap<String, Show>()
    private var now = 0L
    private var popular: List<String> = emptyList()
    private var trending: List<String> = emptyList()
    private var trendingDay: List<String> = emptyList()
    private var frMapCache: Map<String, List<Show>>? = null

    private var username: String? = null
    private var prog = ArrayList<Prog>()
    private var favs = ArrayList<String>()

    private var playing: Playing? = null
    private var busy = false
    private var detailRefresh: (() -> Unit)? = null
    private val metaCache = HashMap<String, Triple<List<Vid>, String, Double?>>()

    private val prefs by lazy { getSharedPreferences("app", MODE_PRIVATE) }

    private val playerLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { onPlayerClosed(it) }

    // ------------------------------------------------------------------ setup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)

        root = FrameLayout(this)
        root.setBackgroundColor(BG)
        spinner = ProgressBar(this).apply { visibility = View.GONE }
        root.addView(spinner, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.CENTER))
        setContentView(root)

        Img.init(applicationContext)
        Net.token = prefs.getString("token", null)

        PlayerEvents.progressListener = { pos, dur -> playing?.let { saveProgress(it, pos, dur) } }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (stack.size > 1) pop() else finish()
            }
        })

        loadAll()
    }

    private fun loadAll() {
        clearStack()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        box.addView(label("ANIME TV", 34, true, ACCENT))
        box.addView(label("Loading…", 16, false, MUTED))
        push(box, null)
        spinner.visibility = View.VISIBLE

        Net.async({
            val j = Net.request("/api/shows")
            var me: JSONObject? = null
            if (Net.token != null) {
                me = try {
                    Net.request("/api/me")
                } catch (e: ApiException) {
                    if (e.status == 401) Net.token = null
                    null
                } catch (e: Exception) {
                    null
                }
            }
            Pair(j, me)
        }, { (j, me) ->
            spinner.visibility = View.GONE
            parseShows(j)
            if (me != null) applyMe(me)
            else if (Net.token == null) prefs.edit().remove("token").apply()
            clearStack()
            push(buildHome(), null)
        }, { e ->
            spinner.visibility = View.GONE
            clearStack()
            val box2 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
            if (isAsleep(e)) {
                box2.addView(label("ANIME TV", 28, true, ACCENT))
                box2.addView(label("Server is asleep", 20, true, Color.WHITE).apply { setPadding(0, dp(10), 0, dp(6)) })
                box2.addView(
                    label(
                        "It wakes up on its own ~30–60s after someone opens the\nsite in a browser. Open it below, wait a bit, then retry.",
                        14, false, MUTED
                    ).apply { gravity = Gravity.CENTER }
                )
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                val open = pill("Open site in browser") { openSiteInBrowser() }
                val retry = pill("Retry") { loadAll() }
                row.addView(open, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)))
                row.addView(retry, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)).apply { leftMargin = dp(12) })
                box2.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(22) })
                push(box2, open)
            } else {
                box2.addView(label("Could not load", 24, true, Color.WHITE))
                box2.addView(label(e.message ?: "Network error", 14, false, MUTED))
                val retry = pill("Retry") { loadAll() }
                box2.addView(retry, LinearLayout.LayoutParams(dp(160), dp(48)).apply { topMargin = dp(20) })
                push(box2, retry)
            }
        })
    }

    /** True for a 503 (server asleep / cold-starting) or a connect timeout, which usually means the same thing. */
    private fun isAsleep(e: Exception): Boolean =
        (e is ApiException && e.status == 503) ||
            e is java.net.SocketTimeoutException ||
            e is java.net.ConnectException

    private fun openSiteInBrowser() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(BuildConfig.SITE_URL)))
        } catch (ex: Exception) {
            toast("No browser app found on this device")
        }
    }

    private fun parseShows(j: JSONObject) {
        val arr = j.optJSONArray("shows") ?: JSONArray()
        val list = ArrayList<Show>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val le = o.optJSONArray("le")
            list.add(
                Show(
                    slug = o.optString("slug"),
                    name = o.optString("name"),
                    poster = o.optString("poster"),
                    movie = o.optBoolean("movie"),
                    langs = strList(o.optJSONArray("langs")),
                    le = if (le != null && le.length() >= 2) intArrayOf(le.optInt(0), le.optInt(1)) else null,
                    genres = strList(o.optJSONArray("genres")),
                    rating = if (o.isNull("rating")) null else o.optDouble("rating"),
                    desc = o.optString("d"),
                    upd = o.optLong("upd"),
                    n = o.optInt("n"),
                    kind = o.optString("kind", "anime"),
                    ord = o.optInt("ord")
                )
            )
        }
        shows = list
        bySlug.clear()
        for (s in list) bySlug[s.slug] = s
        frMapCache = null
        now = j.optLong("now", System.currentTimeMillis() / 1000)
        popular = strList(j.optJSONArray("popular"))
        trending = strList(j.optJSONArray("trending")).ifEmpty { popular }
        trendingDay = strList(j.optJSONArray("trending_day"))
    }

    private fun applyMe(me: JSONObject) {
        username = me.optJSONObject("user")?.optString("username")
        prog.clear()
        val p = me.optJSONArray("progress") ?: JSONArray()
        for (i in 0 until p.length()) {
            val o = p.optJSONObject(i) ?: continue
            prog.add(Prog(o.optString("slug"), o.optInt("season"), o.optInt("episode"), o.optDouble("pos"), o.optDouble("dur")))
        }
        favs = ArrayList(strList(me.optJSONArray("favs")))
    }

    private fun strList(a: JSONArray?): List<String> {
        if (a == null) return emptyList()
        val out = ArrayList<String>(a.length())
        for (i in 0 until a.length()) out.add(a.optString(i))
        return out
    }

    // ------------------------------------------------------------------ home

    private fun isAnime(s: Show) = s.kind != "cartoon"

    private fun grouped(list: List<Show>): List<Item> =
        dedupeByAnime(list).map { s -> groupedItem(s, null) { sw -> openDetail(sw) } }

    /** "Latest episodes" / "Recently added" card: accent "S1 · E5" line + title (website epCard). */
    private fun epItem(s: Show): Item {
        val nw = isNew(s)
        return Item(
            s, if (s.le != null) null else subOf(s), { openDetail(s) }, badge = if (nw) "NEW" else null,
            epLine = s.le?.let { "S${it[0]} · E${it[1]}" + if (nw) " · ${ago(s.upd)}" else "" }
        )
    }

    private fun buildHome(): View {
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false; clipChildren = false }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(32), dp(20), dp(32), dp(40))
            clipChildren = false
        }
        scroll.addView(col)

        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(label("ANIME TV", 26, true, ACCENT), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val search = pill("Search") { openBrowse() }
        val browse = pill("Browse all") { openBrowse() }
        val acct = pill(username ?: "Sign in") { openAccount() }
        for (b in listOf(search, browse, acct)) {
            head.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)).apply { leftMargin = dp(10) })
        }
        col.addView(head)

        val signedIn = username != null
        val contAll = prog.mapNotNull { p -> bySlug[p.slug]?.let { s -> Pair(p, s) } }

        val trendD = trendingDay.mapNotNull { bySlug[it] }
        var trend = trending.mapNotNull { bySlug[it] }
        if (trend.size < 30) {
            val have = trend.map { it.slug }.toHashSet()
            trend = trend + shows.filter { isAnime(it) && it.poster.isNotEmpty() && !have.contains(it.slug) }
                .sortedWith(compareByDescending<Show> { it.rating ?: 0.0 }.thenByDescending { it.ord })
                .take(30 - trend.size)
        }
        val fresh = shows.filter { isNew(it) && isAnime(it) }.sortedByDescending { it.upd }
        val freshSet = fresh.map { it.slug }.toHashSet()
        val recent = shows.filter { !it.movie && isAnime(it) && it.poster.isNotEmpty() && !freshSet.contains(it.slug) }
            .sortedByDescending { it.ord }

        // ---- hero: what you were watching, else the top trending show
        val c0 = contAll.firstOrNull()
        val heroShow = c0?.second ?: trend.firstOrNull { it.poster.isNotEmpty() } ?: recent.firstOrNull()
        if (heroShow != null) col.addView(buildHero(heroShow, c0?.first), LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(14) })

        if (trendD.size >= 4) row(col, "Trending today", grouped(trendD))
        if (trend.size >= 4) row(col, "Trending this week", grouped(trend))

        // ---- genre chips (website "Genres")
        val gcnt = HashMap<String, Int>()
        for (x in shows) if (isAnime(x) && x.poster.isNotEmpty()) for (g in x.genres) gcnt[g] = (gcnt[g] ?: 0) + 1
        val topG = gcnt.filter { it.value >= 3 }.keys.sortedByDescending { gcnt[it] }.take(8)
        if (topG.isNotEmpty()) {
            col.addView(label("Genres", 18, true, Color.WHITE).apply { setPadding(dp(4), dp(18), 0, dp(8)) })
            val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; clipChildren = false; clipToPadding = false }
            val lin = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(4), dp(4), dp(4), dp(4)) }
            for (g in topG) {
                lin.addView(pill(g) { openBrowse(g) { x -> x.genres.contains(g) } },
                    LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)).apply { rightMargin = dp(10) })
            }
            hs.addView(lin)
            col.addView(hs)
        }

        row(col, "Latest episodes", fresh.take(20).map { epItem(it) })

        if (signedIn) {
            val cont = contAll.take(15).map { (p, s) ->
                val pct = if (p.dur > 0) (p.pos * 100 / p.dur).toInt().coerceIn(0, 100) else 0
                Item(s, null, { resume(s, p) }, pct = pct,
                    epLine = if (s.movie) "$pct% watched" else "S${p.season} · E${p.episode} · $pct%")
            }
            row(col, "Continue watching", cont)
            row(col, "My list", grouped(favs.mapNotNull { bySlug[it] }.take(20)))
        }

        row(col, "Recently added", recent.take(20).map { epItem(it) })

        val pop = popular.mapNotNull { bySlug[it] }
        if (pop.size >= 4) row(col, "Popular", grouped(pop))

        val top = shows.filter { (it.rating ?: 0.0) >= 7.5 && it.poster.isNotEmpty() }
            .sortedByDescending { it.rating }.take(20)
        if (top.size >= 4) row(col, "Top rated", grouped(top))

        // ---- one rail per genre (website does the same, top 8 by size)
        for (g in topG) {
            val l = shows.filter { isAnime(it) && it.poster.isNotEmpty() && it.genres.contains(g) }
                .sortedWith(compareByDescending<Show> { it.rating ?: 0.0 }.thenByDescending { it.ord })
                .take(40)
            row(col, g, grouped(l)) { openBrowse(g) { x -> x.genres.contains(g) } }
        }

        for (l in listOf("Hindi", "Tamil", "Telugu")) {
            val items = shows.filter { it.langs.contains(l) && !it.movie && isAnime(it) && it.poster.isNotEmpty() }
                .sortedByDescending { it.upd }.take(20)
            row(col, "$l anime", grouped(items)) {
                openBrowse("$l anime") { x -> x.langs.contains(l) && !x.movie && isAnime(x) }
            }
        }

        row(col, "Cartoons", grouped(shows.filter { !it.movie && !isAnime(it) && it.poster.isNotEmpty() }.sortedByDescending { it.ord }.take(20))) {
            openBrowse("Cartoons") { x -> !x.movie && !isAnime(x) }
        }
        row(col, "Anime movies", grouped(shows.filter { it.movie && it.poster.isNotEmpty() }.take(20))) {
            openBrowse("Anime movies") { x -> x.movie }
        }

        return scroll
    }

    /** Big banner at the top of home (website hero): continue-watching show if any, else top trending. */
    private fun buildHero(s: Show, p: Prog?): View {
        val h = dp(250)
        val f = FrameLayout(this).apply {
            background = rr(0xFF141419.toInt(), 18)
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(18).toFloat()) }
            }
            clipToOutline = true
            clipChildren = true
        }
        val url = Net.abs(s.poster)
        val bg = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setColorFilter(0xB0000000.toInt(), PorterDuff.Mode.SRC_ATOP)
        }
        f.addView(bg, FrameLayout.LayoutParams(-1, h))
        if (s.poster.isNotEmpty()) Img.load(bg, url, dp(480))

        val scrim = View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xF00A0A0D.toInt(), 0x990A0A0D.toInt(), 0x000A0A0D))
        }
        f.addView(scrim, FrameLayout.LayoutParams(-1, h))

        if (s.poster.isNotEmpty()) {
            val art = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
            Img.load(art, url, dp(300))
            f.addView(art, FrameLayout.LayoutParams(dp(170), h - dp(36), Gravity.END or Gravity.CENTER_VERTICAL).apply { rightMargin = dp(30) })
        }

        val txt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(28), dp(16), dp(8), dp(16)) }
        val tag = label(if (p != null) "CONTINUE WATCHING" else "TRENDING", 11, true, Color.WHITE).apply {
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(ACCENT, 0xFFFF8F45.toInt())).apply { cornerRadius = dp(8).toFloat() }
        }
        txt.addView(tag, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        txt.addView(label(s.name, 28, true, Color.WHITE).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(8), 0, 0) })
        val meta = ArrayList<String>()
        s.rating?.takeIf { it > 0 }?.let { meta.add("★ " + String.format(Locale.US, "%.1f", it)) }
        if (s.movie) meta.add("Movie")
        if (s.genres.isNotEmpty()) meta.add(s.genres.take(3).joinToString(" · "))
        if (s.langs.isNotEmpty()) meta.add(s.langs.take(3).joinToString("/") + " dub")
        txt.addView(label(meta.joinToString("   "), 13, false, 0xFFE4E6EE.toInt()).apply { setPadding(0, dp(4), 0, dp(4)) })
        if (s.desc.isNotEmpty()) txt.addView(label(s.desc, 13, false, 0xFFD0D0D8.toInt()).apply { maxLines = 3; ellipsize = TextUtils.TruncateAt.END })

        val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(12), 0, 0) }
        val main = pill(
            if (p != null) "▶ Resume" + (if (s.movie) "" else " S${p.season} E${p.episode}") else "▶ Watch now"
        ) {
            when {
                p != null -> resume(s, p)
                s.le != null -> play(s, s.le[0], s.le[1], 0.0, metaCache[s.slug]?.first ?: emptyList(), false)
                else -> openDetail(s)
            }
        }
        val det = pill("Details") { openDetail(s) }
        btns.addView(main, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)))
        btns.addView(det, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)).apply { leftMargin = dp(12) })
        txt.addView(btns)
        f.addView(txt, FrameLayout.LayoutParams((resources.displayMetrics.widthPixels * 0.58f).toInt(), h, Gravity.START))
        return f
    }

    private fun row(col: LinearLayout, title: String, items: List<Item>, more: (() -> Unit)? = null) {
        if (items.isEmpty()) return
        val th = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(18), 0, dp(6)) }
        th.addView(label(title, 18, true, Color.WHITE), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        if (more != null) {
            th.addView(pill("See all →") { more() }.apply { setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(30)).apply { leftMargin = dp(14) })
        }
        col.addView(th)
        val hs = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            clipChildren = false
            clipToPadding = false
        }
        val lin = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; clipChildren = false }
        for (item in items.take(60)) {
            val vh = newCard()
            bindItem(vh, item)
            lin.addView(vh.root, LinearLayout.LayoutParams(dp(CARD_W), ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        hs.addView(lin)
        col.addView(hs)
    }

    private fun epLabel(s: Show): String =
        s.le?.let { "S${it[0]} · E${it[1]}" } ?: if (s.langs.isNotEmpty()) s.langs.take(3).joinToString(" · ") else "Movie"

    // ------------------------------------------------------------------ season grouping (same anime, different seasons)

    private val LANG_WORDS = Regex(
        """\s*[-\u2013]?\s*(hindi|tamil|telugu|malayalam|bengali|multi|dubbed|subbed|dub|sub|uncut|crunchyroll|jio\s*cinema)\b.*$""",
        RegexOption.IGNORE_CASE
    )
    private val SEASON_WORD = Regex("""\bseason\s*0*(\d+)\b""", RegexOption.IGNORE_CASE)
    private val PARENS = Regex("""\([^)]*\)""")
    private val NON_ALNUM = Regex("""[^a-z0-9]+""")

    /** Strips language/season/parenthetical noise so "One Piece Season 2 (East Blue)" -> "One Piece". */
    private fun baseName(n: String): String {
        var s = n
        s = s.replace(PARENS, " ")
        s = s.replace(LANG_WORDS, "")
        s = s.replace(SEASON_WORD, " ")
        s = s.replace(Regex("""\bepisodes\b""", RegexOption.IGNORE_CASE), " ")
        s = s.replace(Regex("""\s+"""), " ").trim().trim('-', '\u2013', ' ')
        return s
    }

    /** Groups every season/dub of the same anime under one key (movies kept separate from series). */
    private fun frKey(s: Show): String {
        val prefix = if (s.movie) "m:" else "s:"
        return prefix + baseName(s.name).lowercase(Locale.ROOT).replace(NON_ALNUM, "")
    }

    private fun seasonNo(s: Show): Int = SEASON_WORD.find(s.name)?.groupValues?.get(1)?.toIntOrNull() ?: 0

    private fun seasonLabel(s: Show, idx: Int): String {
        val n = SEASON_WORD.find(s.name)?.groupValues?.get(1)?.toIntOrNull()
        return when {
            n != null -> "Season $n"
            s.movie -> "Movie"
            else -> "Part ${idx + 1}"
        }
    }

    /** All shows sharing a given anime's frKey (its other seasons/dubs), season-ordered. */
    private fun frMap(): Map<String, List<Show>> {
        frMapCache?.let { return it }
        val grouped = HashMap<String, MutableList<Show>>()
        for (s in shows) grouped.getOrPut(frKey(s)) { ArrayList() }.add(s)
        val sorted = grouped.mapValues { (_, members) -> members.sortedBy { seasonNo(it) } }
        frMapCache = sorted
        return sorted
    }

    /** Keeps only the first entry per anime, in list order — same effect as the website's dedupe(). */
    private fun dedupeByAnime(list: List<Show>): List<Show> {
        val seen = HashSet<String>()
        return list.filter { seen.add(frKey(it)) }
    }

    private fun isNew(s: Show) = s.upd > 0 && now - s.upd < 7 * 86400

    private fun ago(t: Long): String {
        val d = maxOf(0L, now - t)
        return when {
            d < 3600 -> "${maxOf(1L, Math.round(d / 60.0))}m ago"
            d < 86400 -> "${Math.round(d / 3600.0)}h ago"
            else -> "${Math.round(d / 86400.0)}d ago"
        }
    }

    /** Same sub-line as the website: "Hindi · Tamil Dub" (+ " · Movie"). */
    private fun subOf(s: Show): String =
        (if (s.langs.isNotEmpty()) s.langs.take(2).joinToString(" · ") + " Dub" else "Anime") +
            if (s.movie) " · Movie" else ""

    /** Builds a row Item like the website's card(): grouped seasons -> "N SEASONS" badge + season picker. */
    private fun groupedItem(s: Show, sub: String?, openClick: (Show) -> Unit): Item {
        val mem = frMap()[frKey(s)] ?: listOf(s)
        return if (mem.size > 1) {
            Item(
                s, "${mem.size} seasons · ${subOf(s)}", { showSeasonPicker(s, mem, openClick) },
                title = baseName(s.name).ifEmpty { s.name }, badge = "${mem.size} SEASONS"
            )
        } else {
            Item(s, subOf(s), { openClick(s) }, badge = if (isNew(s)) "NEW" else null)
        }
    }

    private fun showSeasonPicker(anchor: Show, mem: List<Show>, openClick: (Show) -> Unit) {
        val labels = mem.mapIndexed { i, x ->
            seasonLabel(x, i) + (x.le?.let { "   ·   S${it[0]} E${it[1]}" } ?: "")
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(baseName(anchor.name).ifEmpty { anchor.name })
            .setItems(labels) { _, i -> openClick(mem[i]) }
            .show()
    }

    private fun rebuildHome() {
        if (stack.isEmpty()) return
        val old = stack[0]
        val idx = root.indexOfChild(old.view)
        val vis = old.view.visibility
        root.removeView(old.view)
        val v = buildHome()
        v.visibility = vis
        root.addView(v, idx, FrameLayout.LayoutParams(-1, -1))
        stack[0] = Screen(v)
        if (stack.size == 1) v.post { v.requestFocus() }
    }

    // ------------------------------------------------------------------ browse / search

    private fun openBrowse(title: String? = null, pre: (Show) -> Boolean = { true }) {
        var type = 0
        var query = ""
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(32), dp(20), dp(32), 0) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val edit = EditText(this).apply {
            hint = "Search anime…"
            setHintTextColor(MUTED)
            setTextColor(Color.WHITE)
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT
            setPadding(dp(16), 0, dp(16), 0)
            background = pillBg()
            textSize = 16f
            isFocusable = true
        }
        bar.addView(edit, LinearLayout.LayoutParams(0, dp(44), 1f))
        val chips = ArrayList<TextView>()
        val gridAdapter = GridAdapter { openDetail(it) }
        fun refilter() {
            val toks = query.lowercase(Locale.ROOT).split(" ").filter { it.isNotEmpty() }
            gridAdapter.items = dedupeByAnime(shows.filter { s ->
                pre(s) && (type == 0 || (type == 1 && !s.movie) || (type == 2 && s.movie)) &&
                    toks.all { s.name.lowercase(Locale.ROOT).contains(it) }
            })
            gridAdapter.notifyDataSetChanged()
        }
        listOf("All", "Series", "Movies").forEachIndexed { i, t ->
            val c = pill(t) {
                type = i
                chips.forEachIndexed { j, ch -> ch.isSelected = j == i }
                refilter()
            }
            c.isSelected = i == 0
            chips.add(c)
            bar.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)).apply { leftMargin = dp(10) })
        }
        if (title != null) col.addView(label(title, 22, true, Color.WHITE).apply { setPadding(dp(4), 0, 0, dp(10)) })
        col.addView(bar)

        val span = maxOf(2, (resources.displayMetrics.widthPixels - dp(64)) / dp(CARD_W + 12))
        val rv = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@MainActivity, span)
            this.adapter = gridAdapter
            clipChildren = false
            clipToPadding = false
            setPadding(0, dp(16), 0, dp(24))
            descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        }
        col.addView(rv, LinearLayout.LayoutParams(-1, 0, 1f))

        val handler = Net.main
        val run = Runnable { refilter() }
        edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString() ?: ""
                handler.removeCallbacks(run)
                handler.postDelayed(run, 250)
            }
        })
        refilter()
        push(col, chips[0])
    }

    private inner class GridAdapter(val click: (Show) -> Unit) : RecyclerView.Adapter<CardVH>() {
        var items: List<Show> = emptyList()
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardVH {
            val vh = newCard()
            vh.root.layoutParams = RecyclerView.LayoutParams(dp(CARD_W), ViewGroup.LayoutParams.WRAP_CONTENT)
            return vh
        }

        override fun getItemCount() = items.size
        override fun onBindViewHolder(holder: CardVH, position: Int) {
            val s = items[position]
            bindItem(holder, groupedItem(s, null) { sw -> click(sw) })
        }
    }

    // ------------------------------------------------------------------ detail

    private fun openDetail(s: Show) {
        val vidsAll = ArrayList<Vid>()
        var season = 0
        val seen = HashSet<String>()

        val page = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(40), dp(28), dp(40), dp(16)) }

        val poster = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(0xFF1A1A22.toInt()) }
        Img.load(poster, Net.abs(s.poster), dp(260))
        page.addView(poster, LinearLayout.LayoutParams(dp(220), dp(320)))

        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(28), 0, 0, 0) }
        page.addView(right, LinearLayout.LayoutParams(0, -1, 1f))

        right.addView(label(s.name, 26, true, Color.WHITE).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END })
        val metaParts = ArrayList<String>()
        s.rating?.let { metaParts.add("★ " + String.format(Locale.US, "%.1f", it)) }
        if (s.genres.isNotEmpty()) metaParts.add(s.genres.take(3).joinToString(" · "))
        if (s.langs.isNotEmpty()) metaParts.add(s.langs.take(3).joinToString("/") + " dub")
        right.addView(label(metaParts.joinToString("   "), 13, false, MUTED).apply { setPadding(0, dp(4), 0, dp(6)) })
        val desc = label(s.desc, 14, false, 0xFFD0D0D8.toInt()).apply { maxLines = 4; ellipsize = TextUtils.TruncateAt.END }
        right.addView(desc)

        val btnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(14), 0, dp(10)) }
        val playBtn = pill("Play") {}
        btnRow.addView(playBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)))
        val favBtn = pill("") {}
        if (username != null) {
            btnRow.addView(favBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)).apply { leftMargin = dp(12) })
        }
        right.addView(btnRow)

        val seasonBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val seasonScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(seasonBar) }
        right.addView(seasonScroll)

        val status = label(if (s.movie) "" else "Loading episodes…", 14, false, MUTED)
        right.addView(status)

        val epAdapter = EpAdapter()
        val rv = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@MainActivity, 4)
            adapter = epAdapter
            clipToPadding = false
            clipChildren = false
            setPadding(0, dp(8), 0, dp(12))
        }
        if (!s.movie) right.addView(rv, LinearLayout.LayoutParams(-1, 0, 1f))

        fun progFor() = prog.firstOrNull { it.slug == s.slug }

        fun refreshButtons() {
            val p = progFor()
            playBtn.text = when {
                p != null && s.movie -> "Resume"
                p != null -> "Resume S${p.season} E${p.episode}"
                s.movie -> "Play"
                else -> "Play S${vidsAll.firstOrNull()?.season ?: 1} E${vidsAll.firstOrNull()?.episode ?: 1}"
            }
            favBtn.text = if (favs.contains(s.slug)) "✓ In my list" else "+ My list"
            epAdapter.notifyDataSetChanged()
        }

        playBtn.setOnClickListener {
            val p = progFor()
            when {
                p != null -> play(s, p.season, p.episode, if (p.dur > 0 && p.pos / p.dur > 0.95) 0.0 else p.pos, vidsAll, false)
                s.movie -> play(s, 0, 0, 0.0, vidsAll, false)
                vidsAll.isEmpty() -> toast("Episodes are still loading")
                else -> play(s, vidsAll[0].season, vidsAll[0].episode, 0.0, vidsAll, false)
            }
        }
        favBtn.setOnClickListener {
            val on = !favs.contains(s.slug)
            if (on) favs.add(0, s.slug) else favs.remove(s.slug)
            refreshButtons()
            Net.async({ Net.request("/api/fav", JSONObject().put("slug", s.slug).put("on", on)) }, {}, {})
        }

        fun showSeason(n: Int) {
            season = n
            epAdapter.items = vidsAll.filter { it.season == n }
            for (i in 0 until seasonBar.childCount) seasonBar.getChildAt(i).isSelected = (seasonBar.getChildAt(i).tag == n)
            epAdapter.notifyDataSetChanged()
        }

        epAdapter.onClick = { v -> play(s, v.season, v.episode, 0.0, vidsAll, false) }
        epAdapter.state = { v ->
            val p = progFor()
            when {
                seen.contains("${v.season}:${v.episode}") -> "✓"
                p != null && p.season == v.season && p.episode == v.episode && p.dur > 0 ->
                    "${(p.pos * 100 / p.dur).toInt().coerceIn(0, 100)}%"
                else -> ""
            }
        }
        epAdapter.isCurrent = { v ->
            val p = progFor()
            p != null && p.season == v.season && p.episode == v.episode
        }

        fun fillMeta(vids: List<Vid>) {
            vidsAll.clear()
            vidsAll.addAll(vids)
            status.visibility = if (vids.isEmpty() && !s.movie) View.VISIBLE else View.GONE
            if (vids.isEmpty() && !s.movie) status.text = "No episodes found"
            seasonBar.removeAllViews()
            val seasons = vids.map { it.season }.distinct().sorted()
            if (seasons.size > 1) {
                for (n in seasons) {
                    val c = pill("Season $n") { showSeason(n) }
                    c.tag = n
                    seasonBar.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)).apply { rightMargin = dp(8) })
                }
            }
            showSeason(progFor()?.season?.takeIf { seasons.contains(it) } ?: seasons.firstOrNull() ?: 1)
            refreshButtons()
        }

        refreshButtons()
        detailRefresh = { refreshButtons() }

        val cached = metaCache[s.slug]
        if (cached != null) {
            fillMeta(cached.first)
        } else {
            Net.async({
                val type = if (s.movie) "movie" else "series"
                val m = Net.request("/meta/$type/raretoons2:${s.slug}.json").optJSONObject("meta") ?: JSONObject()
                val vids = ArrayList<Vid>()
                val arr = m.optJSONArray("videos") ?: JSONArray()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    vids.add(Vid(o.optInt("season", 1), o.optInt("episode"), o.optString("title")))
                }
                vids.sortWith(compareBy({ it.season }, { it.episode }))
                Triple(vids, m.optString("overview"), if (m.isNull("rating")) null else m.optDouble("rating"))
            }, { t ->
                metaCache[s.slug] = t
                if (desc.text.isNullOrEmpty() && t.second.isNotEmpty()) desc.text = t.second
                fillMeta(t.first)
            }, { e ->
                status.text = "Could not load episodes: ${e.message}"
            })
        }

        if (username != null && !s.movie) {
            Net.async({
                val a = Net.request("/api/seen/${s.slug}").optJSONArray("seen")
                strList(a)
            }, { list ->
                seen.addAll(list)
                epAdapter.notifyDataSetChanged()
            }, {})
        }

        push(page, playBtn)
    }

    /** Numbered episode box, matching the website's "Episodes" grid (1 2 3 4 per row). */
    private inner class EpAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        var items: List<Vid> = emptyList()
        var onClick: (Vid) -> Unit = {}
        var state: (Vid) -> String = { "" }       // "✓" seen, "NN%" in progress, "" otherwise
        var isCurrent: (Vid) -> Boolean = { false } // true selects/highlights this box (current episode)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val box = FrameLayout(this@MainActivity).apply {
                layoutParams = RecyclerView.LayoutParams(-1, dp(64)).apply {
                    val m = dp(6)
                    setMargins(m, m, m, m)
                }
            }
            val num = label("", 17, true, Color.WHITE).apply {
                tag = "n"
                gravity = Gravity.CENTER
            }
            box.addView(num, FrameLayout.LayoutParams(-1, -1))
            val dot = View(this@MainActivity).apply {
                tag = "dot"
                background = GradientDrawable().apply { setColor(ACCENT); cornerRadius = dp(4).toFloat() }
                visibility = View.GONE
            }
            box.addView(dot, FrameLayout.LayoutParams(dp(8), dp(8), Gravity.TOP or Gravity.END).apply {
                topMargin = dp(8); rightMargin = dp(8)
            })
            val st = label("", 10, true, ACCENT).apply {
                tag = "s"
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                setPadding(0, 0, 0, dp(5))
            }
            box.addView(st, FrameLayout.LayoutParams(-1, -1))
            epBoxStyle(box)
            return object : RecyclerView.ViewHolder(box) {}
        }

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: RecyclerView.ViewHolder, position: Int) {
            val v = items[position]
            val box = h.itemView as FrameLayout
            (box.findViewWithTag<TextView>("n")).text = "${v.episode}"
            val st = state(v)
            (box.findViewWithTag<TextView>("s")).text = if (st == "✓") "" else st
            box.findViewWithTag<View>("dot").visibility = if (st == "✓") View.VISIBLE else View.GONE
            box.isSelected = isCurrent(v)
            box.setOnClickListener { onClick(v) }
        }
    }

    /** Rounded box background for an episode number: accent outline when selected/current, accent fill on focus. */
    private fun epBoxStyle(v: View) {
        v.isFocusable = true
        v.isClickable = true
        v.background = StateListDrawable().apply {
            addState(
                intArrayOf(android.R.attr.state_focused),
                GradientDrawable().apply { setColor(ACCENT); cornerRadius = dp(10).toFloat() }
            )
            addState(
                intArrayOf(android.R.attr.state_selected),
                GradientDrawable().apply {
                    setColor(0xFF1A1A22.toInt())
                    cornerRadius = dp(10).toFloat()
                    setStroke(dp(2), ACCENT)
                }
            )
            addState(intArrayOf(), GradientDrawable().apply { setColor(0xFF1A1A22.toInt()); cornerRadius = dp(10).toFloat() })
        }
        v.onFocusChangeListener = View.OnFocusChangeListener { x, f ->
            x.animate().scaleX(if (f) 1.08f else 1f).scaleY(if (f) 1.08f else 1f).setDuration(110).start()
            // NOT bringToFront(): inside a LinearLayout it moves the child to the END of the row, so D-pad RIGHT had nowhere to go.
            x.translationZ = if (f) dp(8).toFloat() else 0f
            if (f) {
                x.post { x.parent?.requestChildRectangleOnScreen(x, android.graphics.Rect(0, 0, x.width, x.height), false) }
            }
        }
    }

    // ------------------------------------------------------------------ playback

    private fun resume(s: Show, p: Prog) {
        val start = if (p.dur > 0 && p.pos / p.dur > 0.95) 0.0 else p.pos
        val vids = metaCache[s.slug]?.first ?: emptyList()
        play(s, p.season, p.episode, start, vids, false)
    }

    private fun play(s: Show, season: Int, episode: Int, start: Double, vidsIn: List<Vid>, auto: Boolean) {
        if (busy) return
        busy = true
        spinner.visibility = View.VISIBLE
        Net.async({
            val path = "/api/watch/${s.slug}" + if (s.movie) "" else "/$season/$episode"
            val arr = Net.request(path).optJSONArray("sources") ?: JSONArray()
            val out = ArrayList<Source>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                out.add(Source(o.optString("lang", "Default"), o.optString("quality"), o.optString("url")))
            }
            out
        }, { sources ->
            busy = false
            spinner.visibility = View.GONE
            if (sources.isEmpty()) {
                toast("No stream available for this one")
                return@async
            }
            pickSource(sources, auto) { src ->
                prefs.edit().putString("lang", src.lang).putString("q", src.quality).apply()
                launchPlayer(s, season, episode, start, vidsIn, sources, src)
            }
        }, { e ->
            busy = false
            spinner.visibility = View.GONE
            if (isAsleep(e)) {
                AlertDialog.Builder(this)
                    .setTitle("Server is asleep")
                    .setMessage("It wakes up on its own ~30\u201360s after someone opens the site in a browser. Open it, wait a bit, then try again.")
                    .setPositiveButton("Open site in browser") { _, _ -> openSiteInBrowser() }
                    .setNegativeButton("Close", null)
                    .show()
            } else {
                toast("Could not load stream: ${e.message}")
            }
        })
    }

    /**
     * First time ever: ask once for language and quality (like the website's player
     * options). The answer is saved ("lang", "q", "vq") and used as the default for every
     * later video, so nothing is asked again. Language / quality can still be changed
     * inside the player at any time. Auto-next never asks.
     */
    private fun pickSource(sources: List<Source>, auto: Boolean, cb: (Source) -> Unit) {
        val lang = prefs.getString("lang", null)
        val q = prefs.getString("q", null)
        val saved = sources.firstOrNull { it.lang == lang && it.quality == q }
            ?: sources.firstOrNull { it.lang == lang }
        val first = sources.firstOrNull() ?: return
        if (prefs.getBoolean("setup_done", false) || auto) {
            cb(saved ?: first)
            return
        }
        askFirstTimeChoice(sources, cb)
    }

    private fun askFirstTimeChoice(sources: List<Source>, cb: (Source) -> Unit) {
        fun askQuality(src: Source) {
            val labels = arrayOf("Auto (best for my internet)", "1080p", "720p", "480p", "360p")
            val values = arrayOf("auto", "1080", "720", "480", "360")
            AlertDialog.Builder(this)
                .setTitle("Video quality")
                .setSingleChoiceItems(labels, 0) { d, i ->
                    d.dismiss()
                    prefs.edit()
                        .putString("lang", src.lang).putString("q", src.quality)
                        .putString("vq", values[i]).putBoolean("setup_done", true).apply()
                    cb(src)
                }
                .setOnCancelListener { cb(src) }   // Back: play with defaults, ask again next time
                .show()
        }
        if (sources.size < 2) {
            askQuality(sources[0])
            return
        }
        val labels = sources.map { (it.lang + "  " + it.quality).trim() }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Choose language")
            .setSingleChoiceItems(labels, 0) { d, i ->
                d.dismiss()
                askQuality(sources[i])
            }
            .setOnCancelListener { cb(sources[0]) }
            .show()
    }

    private fun launchPlayer(s: Show, season: Int, episode: Int, start: Double, vids: List<Vid>, sources: List<Source>, src: Source) {
        val url = Net.abs(src.url)
        if (!url.startsWith("https://")) {
            toast("This stream is not HTTPS, cannot play")
            return
        }
        playing = Playing(s, season, episode, vids)
        PlayerEvents.reset()
        val title = if (s.movie) s.name else "${s.name}  S$season E$episode"
        val srcArr = JSONArray()
        var srcIdx = 0
        sources.forEachIndexed { i, x ->
            if (x === src) srcIdx = i
            srcArr.put(JSONObject().put("lang", x.lang).put("quality", x.quality).put("url", x.url))
        }
        val vidArr = JSONArray()
        vids.forEach { vidArr.put(JSONObject().put("season", it.season).put("episode", it.episode).put("title", it.title)) }
        playerLauncher.launch(
            Intent(this, PlayerActivity::class.java)
                .putExtra(PlayerActivity.EXTRA_URL, url)
                .putExtra(PlayerActivity.EXTRA_TITLE, title)
                .putExtra(PlayerActivity.EXTRA_START_SEC, start)
                .putExtra(PlayerActivity.EXTRA_SOURCES_JSON, srcArr.toString())
                .putExtra(PlayerActivity.EXTRA_SRC_INDEX, srcIdx)
                .putExtra(PlayerActivity.EXTRA_VIDS_JSON, vidArr.toString())
                .putExtra(PlayerActivity.EXTRA_SEASON, season)
                .putExtra(PlayerActivity.EXTRA_EPISODE, episode)
        )
    }

    private fun onPlayerClosed(result: ActivityResult) {
        val pl = playing ?: return
        val d = result.data
        val pos = d?.getDoubleExtra(PlayerActivity.RESULT_POS_SEC, PlayerEvents.lastPosSec) ?: PlayerEvents.lastPosSec
        val dur = d?.getDoubleExtra(PlayerActivity.RESULT_DUR_SEC, PlayerEvents.lastDurSec) ?: PlayerEvents.lastDurSec
        val ended = d?.getBooleanExtra(PlayerActivity.RESULT_ENDED, false) ?: false
        val error = d?.getStringExtra(PlayerActivity.RESULT_ERROR)
        if (!error.isNullOrEmpty()) toast("Playback error: $error")
        if (dur > 0) saveProgress(pl, if (ended) dur else pos, dur)

        // Prev / Next pill pressed inside the player -> go straight to that episode.
        val jumpSeason = d?.getIntExtra(PlayerActivity.RESULT_JUMP_SEASON, -1) ?: -1
        val jumpEpisode = d?.getIntExtra(PlayerActivity.RESULT_JUMP_EPISODE, -1) ?: -1
        if (jumpSeason >= 0 && jumpEpisode >= 0) {
            play(pl.show, jumpSeason, jumpEpisode, 0.0, pl.vids, false)
            return
        }

        detailRefresh?.invoke()
        if (stack.size == 1) rebuildHome()

        val autoNextOn = prefs.getBoolean("auto_next", true)
        if (ended && !pl.show.movie && autoNextOn) {
            val i = pl.vids.indexOfFirst { it.season == pl.season && it.episode == pl.episode }
            val next = if (i >= 0) pl.vids.getOrNull(i + 1) else null
            if (next != null) play(pl.show, next.season, next.episode, 0.0, pl.vids, true)
        }
    }

    private fun saveProgress(p: Playing, pos: Double, dur: Double) {
        if (dur <= 0) return
        val i = prog.indexOfFirst { it.slug == p.show.slug }
        if (i >= 0) prog.removeAt(i)
        prog.add(0, Prog(p.show.slug, p.season, p.episode, pos, dur))
        if (Net.token == null) return
        val body = JSONObject().put("slug", p.show.slug).put("season", p.season).put("episode", p.episode)
            .put("pos", pos).put("dur", dur)
        Net.async({ Net.request("/api/progress", body) }, {}, {})
    }

    // ------------------------------------------------------------------ account

    private fun openAccount() {
        if (username != null) {
            AlertDialog.Builder(this)
                .setTitle("Signed in as $username")
                .setPositiveButton("Sign out") { _, _ ->
                    Net.async({ Net.request("/api/logout", JSONObject()) }, {}, {})
                    Net.token = null
                    prefs.edit().remove("token").apply()
                    username = null
                    prog.clear()
                    favs.clear()
                    rebuildHome()
                }
                .setNegativeButton("Close", null)
                .show()
            return
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(12), dp(24), 0) }
        val u = EditText(this).apply { hint = "Username"; setSingleLine(); inputType = InputType.TYPE_CLASS_TEXT }
        val p = EditText(this).apply {
            hint = "Password"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        box.addView(u)
        box.addView(p)
        fun submit(mode: String) {
            val body = JSONObject().put("username", u.text.toString().trim()).put("password", p.text.toString())
            spinner.visibility = View.VISIBLE
            Net.async({
                val j = Net.request("/api/$mode", body)
                Net.token = j.optString("token")
                Pair(j, Net.request("/api/me"))
            }, { (j, me) ->
                spinner.visibility = View.GONE
                prefs.edit().putString("token", j.optString("token")).apply()
                applyMe(me)
                rebuildHome()
            }, { e ->
                spinner.visibility = View.GONE
                Net.token = null
                toast(e.message ?: "Failed")
            })
        }
        AlertDialog.Builder(this)
            .setTitle("Account")
            .setView(box)
            .setPositiveButton("Sign in") { _, _ -> submit("login") }
            .setNeutralButton("Create account") { _, _ -> submit("signup") }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ------------------------------------------------------------------ screens / views

    private fun push(view: View, focus: View?) {
        stack.lastOrNull()?.let {
            it.lastFocus = currentFocus
            it.view.visibility = View.GONE
        }
        root.addView(view, root.childCount - 1, FrameLayout.LayoutParams(-1, -1))
        stack.add(Screen(view))
        view.post { (focus ?: view).requestFocus() }
    }

    private fun pop() {
        if (stack.size <= 1) return
        val top = stack.removeAt(stack.size - 1)
        root.removeView(top.view)
        detailRefresh = null
        val prev = stack.last()
        prev.view.visibility = View.VISIBLE
        prev.view.post { (prev.lastFocus ?: prev.view).requestFocus() }
    }

    private fun clearStack() {
        for (s in stack) root.removeView(s.view)
        stack.clear()
        detailRefresh = null
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun label(text: String, sp: Int, bold: Boolean, color: Int) = TextView(this).apply {
        this.text = text
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp.toFloat())
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.START
    }

    private fun rr(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }

    private fun pillBg() = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_focused), rr(ACCENT, 20))
        addState(intArrayOf(android.R.attr.state_selected), rr(0xFF7A2A19.toInt(), 20))
        addState(intArrayOf(), rr(0xFF26262F.toInt(), 20))
    }

    private fun pill(text: String, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(dp(18), 0, dp(18), 0)
        background = pillBg()
        isFocusable = true
        isClickable = true
        setOnClickListener { onClick() }
        onFocusChangeListener = View.OnFocusChangeListener { v, f ->
            v.animate().scaleX(if (f) 1.05f else 1f).scaleY(if (f) 1.05f else 1f).setDuration(110).start()
        }
    }

    /** Accent frame + slight zoom when a card/row gets D-pad focus. */
    private fun focusStyle(v: View, scale: Float) {
        v.isFocusable = true
        v.isClickable = true
        v.background = StateListDrawable().apply {
            addState(
                intArrayOf(android.R.attr.state_focused),
                GradientDrawable().apply {
                    setColor(0x22FFFFFF)
                    cornerRadius = dp(20).toFloat()
                    setStroke(dp(3), ACCENT)
                }
            )
            addState(intArrayOf(), GradientDrawable().apply { setColor(Color.TRANSPARENT) })
        }
        v.onFocusChangeListener = View.OnFocusChangeListener { x, f ->
            x.animate().scaleX(if (f) scale else 1f).scaleY(if (f) scale else 1f).setDuration(110).start()
            // NOT bringToFront(): inside a LinearLayout it moves the card to the END of the row, so D-pad RIGHT had nowhere to go.
            x.translationZ = if (f) dp(8).toFloat() else 0f
            if (f) {
                // Scroll every ancestor HorizontalScrollView/ScrollView into place the instant
                // focus lands here, instead of waiting on the platform's own lazy scroll-into-view
                // (that lag is what made the D-pad feel like it needed two presses per row).
                x.post { x.parent?.requestChildRectangleOnScreen(x, android.graphics.Rect(0, 0, x.width, x.height), false) }
            }
        }
    }

    private fun chip(size: Float, bg: Int, fg: Int, bold: Boolean = true) = TextView(this).apply {
        setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        setTextColor(fg)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        maxLines = 1
        setPadding(dp(7), dp(3), dp(7), dp(3))
        background = rr(bg, 6)
        visibility = View.GONE
    }

    /**
     * Website-style card: 16:9 landscape thumbnail (portrait art shown whole over a dimmed copy of itself),
     * language + episode chips at the bottom, rating top-right, green badge top-left, progress bar, then title + sub.
     */
    private fun newCard(): CardVH {
        val thumbH = dp(CARD_W - 10) * 9 / 16

        // outer wrapper = focus ring + room for the zoom, inner = the rounded panel
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(5), dp(5), dp(5), dp(5))
            clipChildren = false
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(0xFF141419.toInt()); cornerRadius = dp(16).toFloat(); setStroke(dp(1), 0xFF25252F.toInt())
            }
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(16).toFloat()) }
            }
            clipToOutline = true
        }
        outer.addView(panel, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))

        val thumb = FrameLayout(this).apply { setBackgroundColor(0xFF1C1C24.toInt()) }
        panel.addView(thumb, LinearLayout.LayoutParams(-1, thumbH))

        val bg = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setColorFilter(0xAA000000.toInt(), PorterDuff.Mode.SRC_ATOP)
            visibility = View.GONE
        }
        thumb.addView(bg, FrameLayout.LayoutParams(-1, -1))
        val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        thumb.addView(iv, FrameLayout.LayoutParams(-1, -1))
        val ph = label("", 38, true, ACCENT).apply { gravity = Gravity.CENTER; visibility = View.GONE }
        thumb.addView(ph, FrameLayout.LayoutParams(-1, -1))

        // bottom overlay gradient + chips
        val ov = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
            setPadding(dp(8), dp(18), dp(8), dp(7))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.TRANSPARENT, 0xB3000000.toInt()))
        }
        val lang = chip(10.5f, 0x33FFFFFF, Color.WHITE)
        val en = chip(10.5f, 0x73000000, Color.WHITE)
        ov.addView(lang)
        ov.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        ov.addView(en)
        thumb.addView(ov, FrameLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        val rt = chip(11f, 0xB8000000.toInt(), 0xFFFFD45E.toInt())
        thumb.addView(rt, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END).apply { topMargin = dp(8); rightMargin = dp(8) })
        val badge = chip(10.5f, 0xFF2FD6A1.toInt(), 0xFF04130E.toInt())
        thumb.addView(badge, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START).apply { topMargin = dp(8); leftMargin = dp(8) })

        // progress bar (continue watching)
        val progWrap = FrameLayout(this).apply { setBackgroundColor(0xFF25252F.toInt()); visibility = View.GONE }
        val prog = View(this).apply { setBackgroundColor(ACCENT) }
        progWrap.addView(prog, FrameLayout.LayoutParams(0, -1))
        panel.addView(progWrap, LinearLayout.LayoutParams(-1, dp(4)))

        // title block
        val tb = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(9), dp(12), dp(11)) }
        val epl = label("", 11, true, ACCENT).apply { maxLines = 1; visibility = View.GONE }
        val name = label("", 13, true, Color.WHITE).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        val sub = label("", 11, false, MUTED).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(2), 0, 0) }
        tb.addView(epl); tb.addView(name); tb.addView(sub)
        panel.addView(tb, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))

        focusStyle(outer, 1.05f)
        return CardVH(outer, bg, iv, ph, lang, en, rt, badge, progWrap, prog, epl, name, sub)
    }

    private fun setTxt(t: TextView, v: String?) {
        t.text = v ?: ""
        t.visibility = if (v.isNullOrEmpty()) View.GONE else View.VISIBLE
    }

    private fun bindItem(h: CardVH, item: Item) {
        val s = item.show
        h.name.text = item.title ?: s.name
        // sub line: hidden on "latest episode" cards, like the website
        if (item.epLine != null && item.sub == null) setTxt(h.sub, null) else setTxt(h.sub, item.sub)
        setTxt(h.epl, item.epLine)

        // chips on the thumbnail (website ovEl): first language (+N) and episode count / Movie
        val L = s.langs
        setTxt(h.lang, if (L.isEmpty()) null else L[0] + if (L.size > 1) " +${L.size - 1}" else "")
        setTxt(h.en, if (s.movie) "Movie" else if (s.n > 0) "${s.n} ep" else null)
        setTxt(h.rt, s.rating?.takeIf { r -> r > 0 }?.let { r -> "★ " + String.format(Locale.US, "%.1f", r) })
        setTxt(h.badge, item.badge)

        if (item.pct != null) {
            h.progWrap.visibility = View.VISIBLE
            h.prog.layoutParams = (h.prog.layoutParams as FrameLayout.LayoutParams).apply {
                width = dp(CARD_W - 10) * item.pct / 100
            }
            h.prog.requestLayout()
        } else h.progWrap.visibility = View.GONE

        // poster
        h.bg.visibility = View.GONE
        h.iv.scaleType = ImageView.ScaleType.CENTER_CROP
        if (s.poster.isEmpty()) {
            h.iv.setImageDrawable(null)
            h.ph.text = (s.name.firstOrNull() ?: '?').uppercase()
            h.ph.visibility = View.VISIBLE
        } else {
            h.ph.visibility = View.GONE
            Img.load(h.iv, Net.abs(s.poster), dp(CARD_W)) { bmp ->
                if (bmp.height > bmp.width * 0.85f) {
                    // portrait poster: show whole, over a dimmed copy of itself, so faces are never cut off
                    h.iv.scaleType = ImageView.ScaleType.FIT_CENTER
                    h.bg.setImageBitmap(bmp)
                    h.bg.visibility = View.VISIBLE
                } else {
                    h.iv.scaleType = ImageView.ScaleType.CENTER_CROP
                    h.bg.visibility = View.GONE
                }
            }
        }
        h.root.setOnClickListener { item.click() }
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
    }

    override fun onDestroy() {
        PlayerEvents.progressListener = null
        super.onDestroy()
    }
}
