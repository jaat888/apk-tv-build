# Anime TV (Android TV wrapper)

Full-screen WebView of the site + native Media3 ExoPlayer for video.

- **Site URL:** `gradle.properties` → `SITE_URL` (only place).
- **Build:** push to GitHub → Actions → "Build Android TV APK" → artifact `anime-tv-debug-apk`.
- **Signing:** `app/debug.keystore` (fixed debug key, so new APKs install over old ones).
- **Needs:** the modified `index.html` (uses `window.AndroidTV`) deployed on the site.

Remote in the player: OK = play/pause · Left/Right = ±10 s (hold = faster) ·
Up/Down = show controls, then volume · Back = close player.

## Player options (v1.1)
- First time you play anything, the app asks **language** and **quality** once. That choice
  becomes the default for every video afterwards (no more asking).
- In the player press Up (controls) then Down: row 1 = **Language · Quality · Audio · Subtitles**,
  row 2 = Prev · Next · Audio ±0.1 · Auto-next. Quality = Auto / 1080p / 720p / 480p / 360p
  (whatever the stream offers). Quality, audio language and subtitle choice are remembered.
