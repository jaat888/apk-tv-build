# Anime TV (Android TV wrapper)

Full-screen WebView of the site + native Media3 ExoPlayer for video.

- **Site URL:** `gradle.properties` → `SITE_URL` (only place). Now: `https://jaat888-anime.hf.space`.
- **Build:** push to GitHub → Actions → "Build Android TV APK" → artifact `anime-tv-debug-apk`.
- **Signing:** `app/debug.keystore` (fixed debug key, so new APKs install over old ones).
- **Needs:** the modified `index.html` (uses `window.AndroidTV`) deployed on the site.

Remote in the player: OK = play/pause · Left/Right = ±10 s (hold = faster) ·
Up/Down = show controls, then volume · Back = close player.

## Player options (v1.1)
- First time you play anything, the app asks **language** and **quality** once. That choice
  becomes the default for every video afterwards (no more asking).
- In the player press Up (controls) then Down: row 1 = **Language · Quality · Audio · Subtitles**,
  row 2 = Prev · Next · Audio ±0.1 · Auto-next. Quality = Auto / 1080p / 720p / 480p / 360p
  (whatever the stream offers). Quality, audio language and subtitle choice are remembered.

## Skip intro / recap / ending (v1.2)
- The player asks the site's `/api/skip/<slug>/<season>/<episode>` in the background (same data and
  rules as the website player: the timestamp whose episode length matches the video is used).
  No answer = no skip, playback is never delayed.
- Row 2 has a **Skip: Auto / Button / Off** pill (remembered). Auto = skips by itself and shows
  "Intro skipped"; Button = a **Skip Intro ›** pill appears bottom-right, press **OK** (or tap) to skip;
  Off = nothing. An ending that runs to the end of the video jumps to the next episode (if Auto-next is on).

## Site guard support (v1.3)
The site (PROTECT mode) can ask things besides plain video links. The app now handles all of them:
- **Device id + TV pass headers:** a random `X-Device` id is made once; the TV pass (below) is sent as
  `X-Captcha`. Both go only to the site's own host, never to other video hosts.
- **TV pass (QR):** when `/api/watch` answers "captcha needed", the TV shows a QR + 6-letter code. Scan it with a
  phone, win the little game, and the TV starts by itself (`/api/tv/new` -> `/api/tv/poll`). The pass is kept for
  hours and a new QR appears when it runs out. Back closes the QR.
- **"Open the page first":** handled quietly (the app opens the anime's meta and asks again).
- **Guest limit:** a "Sign in needed" message (from the main screen it opens the sign-in box).
- **Heartbeat:** every 30 s `/api/hb/<token>`; if the link is nearly over or no longer valid, a fresh link is
  fetched and playback continues from the same second.
- The anime page now uses the new id prefix `wa2:`.


## Fixes (v1.4)
- **Exit:** Back / Exit / Stop now close the player in one press, even when a control pill has focus.
- **Quality:** picking 720p / 1080p etc. now forces that exact quality and applies at once (it used to be only a ceiling that waited for the buffer to play out).
- **Seasons:** all dubs of the same season (different languages OR different companies in the same language) are shown as ONE season; the dub picker then lists them, with the company name when two dubs would read the same.
